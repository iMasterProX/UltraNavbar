package com.minsoo.ultranavbar.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.minsoo.ultranavbar.core.Constants
import com.minsoo.ultranavbar.core.SplitScreenHelper
import com.minsoo.ultranavbar.core.WindowAnalyzer
import com.minsoo.ultranavbar.model.NavAction
import com.minsoo.ultranavbar.overlay.NavBarOverlay
import com.minsoo.ultranavbar.settings.SettingsManager
import com.minsoo.ultranavbar.util.DeviceProfile

/**
 * 네비게이션 바 접근성 서비스
 *
 * 리팩토링된 구조:
 * - WindowAnalyzer: 윈도우 상태 분석 (전체화면, IME, 알림 패널 등)
 * - NavBarOverlay: 오버레이 표시/숨김
 */
class NavBarAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "NavBarAccessibility"
        private const val HOME_ENTRY_STABILIZE_MS = 400L  // 홈 진입 후 안정화 시간
        private const val HOME_EXIT_STABILIZE_MS = 500L   // 홈 이탈 후 안정화 시간 (windows 소스의 잘못된 재진입 방지)
        private const val HOME_RECENT_APP_SUPPRESS_MS = 550L
        private const val HOME_ACTION_STALE_NON_LAUNCHER_MS = 1500L
        private const val HOME_ACTION_OVERLAY_GUARD_MS = 700L
        private const val HOME_ACTION_FAST_HOME_ENTRY_MS = 1300L
        private const val BACK_EXIT_PREVIEW_PROBE_INTERVAL_MS = 80L
        private const val BACK_EXIT_PREVIEW_PROBE_ATTEMPTS = 4
        private const val HOME_ENTRY_STALE_APP_EVENT_GUARD_MS = 1100L
        private const val RECENTS_EVENT_FALSE_DEBOUNCE_MS = 420L
        private const val BROADCAST_DRAWER_STATE_GUARD_MS = 1500L
        private const val ORIENTATION_CHANGE_STABILIZE_MS = 500L  // 화면 회전 후 안정화 시간
        private const val DISABLED_HOME_RECOVERY_WINDOW_MS = 5000L
        private const val SPLIT_FOREGROUND_STALE_MS = 2500L
        private const val EMPTY_SPLIT_EXIT_MS = 5000L
        private const val GOOGLE_QUICKSEARCHBOX_PACKAGE = "com.google.android.googlequicksearchbox"

        // 방향 고정 브로드캐스트 액션
        const val ACTION_APPLY_ORIENTATION_LOCK = "com.minsoo.ultranavbar.ACTION_APPLY_ORIENTATION_LOCK"
        const val ACTION_REMOVE_ORIENTATION_LOCK = "com.minsoo.ultranavbar.ACTION_REMOVE_ORIENTATION_LOCK"

        @Volatile
        var instance: NavBarAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    // === 컴포넌트 ===
    private var overlay: NavBarOverlay? = null
    private var orientationLockView: android.view.View? = null  // 화면 방향 강제용 오버레이
    private lateinit var settings: SettingsManager
    private lateinit var windowAnalyzer: WindowAnalyzer
    private lateinit var keyEventHandler: KeyEventHandler
    private lateinit var powerManager: PowerManager
    private val notificationTracker = NotificationTracker()

    private val handler = Handler(Looper.getMainLooper())

    // === 상태 ===
    private var currentPackage: String = ""
    private var currentClassName: String = ""
    private var currentClassNameAt: Long = 0
    private var currentOrientation: Int = Configuration.ORIENTATION_UNDEFINED
    private var isFullscreen: Boolean = false
    private var fullscreenSlidePendingShow: Boolean = false
    private var isOnHomeScreen: Boolean = false
    private var isRecentsVisible: Boolean = false
    private var isAppDrawerOpen: Boolean = false
    private var lastBroadcastDrawerStateAt: Long = 0L
    private var isLauncherIconDragActive: Boolean = false
    private var isNotificationPanelOpen: Boolean = false
    private var isQuickSettingsOpen: Boolean = false
    private var isWallpaperPreviewVisible: Boolean = false
    private var isImeVisible: Boolean = false
    private var isSplitScreenMode: Boolean = false  // 분할화면 모드 상태
    private var wasSplitScreenUsed: Boolean = false  // 분할화면 사용 이력 (최근 앱 종료 후 복구용)
    private var lastImeEventAt: Long = 0
    private var lastNonLauncherEventAt: Long = 0
    private var lastHomeEntryAt: Long = 0  // 홈 진입 안정화용
    private var lastHomeExitAt: Long = 0   // 홈 이탈 안정화용
    private var lastOrientationChangeAt: Long = 0  // 화면 회전 안정화용
    private var lastSplitRecoveryAt: Long = 0
    private var lastNonLauncherPackage: String = ""
    private var lastNonLauncherPackageAt: Long = 0
    private var lastNonLauncherClassName: String = ""
    private var lastNonLauncherClassAt: Long = 0
    private var lastHomeActionAt: Long = 0
    private var lastHomeActionSourcePackage: String = ""
    private var emptySplitSince: Long = 0
    private var lastDisabledAppHideAt: Long = 0
    private var isScreenInteractive: Boolean = true

    // === 디바운스/폴링 ===
    private var pendingStateCheck: Runnable? = null
    private var pendingHomeReturnProbe: Runnable? = null
    private var pendingBackExitPreviewProbe: Runnable? = null
    private var fullscreenPoll: Runnable? = null
    private var unlockFadeRunnable: Runnable? = null
    private var batteryMonitorRunnable: Runnable? = null
    private var pendingRecentsEventCloseRunnable: Runnable? = null
    private var windowRecoveryRunnable: Runnable? = null  // 윈도우 복구용
    private var disabledAppRecoveryRunnable: Runnable? = null  // 비활성화 앱 복구용

    // === 브로드캐스트 리시버 ===
    private val settingsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Constants.Action.SETTINGS_CHANGED -> {
                    Log.d(TAG, "Settings changed, refreshing overlay")
                    overlay?.refreshSettings()
                    updateOverlayVisibility(forceFade = true)
                }
                Constants.Action.RELOAD_BACKGROUND -> {
                    Log.d(TAG, "Reloading background images")
                    overlay?.reloadBackgroundImages()
                }
                Constants.Action.UPDATE_BUTTON_COLORS -> {
                    Log.d(TAG, "Updating background/button colors")
                    overlay?.refreshBackgroundStyle()
                }
                ACTION_APPLY_ORIENTATION_LOCK -> {
                    Log.d(TAG, "Applying orientation lock from broadcast")
                    applyOrientationLock()
                }
                ACTION_REMOVE_ORIENTATION_LOCK -> {
                    Log.d(TAG, "Removing orientation lock from broadcast")
                    removeOrientationLock()
                }
            }
        }
    }

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    isScreenInteractive = false
                    Log.d(TAG, "Screen off, hiding overlay")
                    overlay?.captureUnlockBackgroundForLock()
                    overlay?.resetUnlockFadeState(clearOverride = false)
                    overlay?.hide(animate = false, showHotspot = false)
                }
                Intent.ACTION_SCREEN_ON -> {
                    isScreenInteractive = true
                    Log.d(TAG, "Screen on, updating visibility")
                    // 잠금화면이 활성화된 상태에서 화면이 켜지면 해제 시 페이드 애니메이션 준비
                    if (windowAnalyzer.isLockScreenActive()) {
                        overlay?.prepareForUnlockFade()
                        return
                    }
                    updateOverlayVisibility(forceFade = false)
                }
                Intent.ACTION_USER_PRESENT -> {
                    Log.d(TAG, "User present, showing with fade")
                    if (overlay?.hasPendingUnlockFade() != true) {
                        overlay?.prepareForUnlockFade()
                    }
                    overlay?.startUnlockFade()
                }
            }
        }
    }

    // 런처 상태 연동 리시버 (LG UltraTab Launcher -> UltraNavbar)
    private val launcherStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val sourcePackage = intent.getStringExtra("source_package") ?: return
            val isHome = intent.getBooleanExtra("is_home", false)
            val isAllApps = intent.getBooleanExtra("is_all_apps", false)
            val isRecents = intent.getBooleanExtra("is_recents", false)
            val isTransitionStart = intent.getBooleanExtra("is_transition_start", false)

            Log.d(TAG, "Launcher state from $sourcePackage: home=$isHome, allApps=$isAllApps, " +
                "recents=$isRecents, transitionStart=$isTransitionStart")

            val drawerChanged: Boolean
            if (isTransitionStart) {
                // 전환 시작 시점: 앱서랍 열림만 즉시 처리 (배경 전환 즉시 트리거)
                // 앱서랍 닫힘은 전환 완료 시점까지 대기 (슬라이드 중 조기 전환 방지)
                if (isAllApps && !isAppDrawerOpen) {
                    isAppDrawerOpen = true
                    drawerChanged = true
                    Log.d(TAG, "App Drawer opening detected via launcher broadcast (transition start)")
                    overlay?.setAppDrawerState(true)
                } else {
                    drawerChanged = false
                }
            }
            // 전환 완료 시점 (기존 onStateSetEnd): 최종 상태 확정
            else {
                if (isAllApps && !isAppDrawerOpen) {
                    isAppDrawerOpen = true
                    drawerChanged = true
                    overlay?.setAppDrawerState(true)
                } else if (!isAllApps && isAppDrawerOpen) {
                    isAppDrawerOpen = false
                    drawerChanged = true
                    Log.d(TAG, "App Drawer closed via launcher broadcast (transition end)")
                    overlay?.setAppDrawerState(false)
                } else {
                    drawerChanged = false
                }
            }
            if (drawerChanged) {
                lastBroadcastDrawerStateAt = SystemClock.elapsedRealtime()
            }
        }
    }

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(
                        android.bluetooth.BluetoothAdapter.EXTRA_STATE,
                        android.bluetooth.BluetoothAdapter.ERROR
                    )
                    if (state == android.bluetooth.BluetoothAdapter.STATE_OFF ||
                        state == android.bluetooth.BluetoothAdapter.STATE_TURNING_OFF) {
                        Log.d(TAG, "Bluetooth turned off, removing orientation lock")
                        if (orientationLockView != null) {
                            removeOrientationLock()
                        }
                    }
                }
                android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(android.bluetooth.BluetoothDevice.EXTRA_DEVICE, android.bluetooth.BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(android.bluetooth.BluetoothDevice.EXTRA_DEVICE)
                    }
                    Log.d(TAG, "Bluetooth device connected: ${device?.name}")
                    if (device != null && isBluetoothKeyboard(device)) {
                        Log.d(TAG, "Keyboard connected, applying orientation lock")
                        applyOrientationLock()
                    }
                }
                android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(android.bluetooth.BluetoothDevice.EXTRA_DEVICE, android.bluetooth.BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(android.bluetooth.BluetoothDevice.EXTRA_DEVICE)
                    }
                    Log.d(TAG, "Bluetooth device disconnected: ${device?.name}")
                    // 방향 고정이 활성 상태일 때만 처리
                    if (orientationLockView != null) {
                        // 물리 키보드가 아직 연결되어 있는지 확인
                        // (isBluetoothKeyboard는 권한/디바이스 상태에 따라 실패할 수 있으므로
                        //  InputDevice API로 실제 연결 상태를 직접 확인)
                        handler.postDelayed({
                            if (instance == null) return@postDelayed
                            if (!hasConnectedPhysicalKeyboard()) {
                                Log.d(TAG, "No physical keyboard connected, removing orientation lock")
                                removeOrientationLock()
                            } else {
                                Log.d(TAG, "Physical keyboard still connected, keeping orientation lock")
                            }
                        }, 500L) // BT 연결 해제 반영 대기
                    }
                }
            }
        }
    }

    // ===== 서비스 생명주기 =====

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!DeviceProfile.isTablet(this)) {
            Log.w(TAG, "Device is not a tablet. Disabling service.")
            disableSelf()
            return
        }

        Log.i(TAG, "Service connected")
        instance = this

        // SplitScreenHelper에 접근성 서비스 참조 설정
        SplitScreenHelper.setAccessibilityService(this)

        initializeComponents()
        setupServiceInfo()
        registerReceivers()

        windowAnalyzer.loadLauncherPackages()
        windowAnalyzer.calculateNavBarHeight()
        currentOrientation = resources.configuration.orientation

        createOverlay()
        updateOverlayVisibility(forceFade = false)

        // Initialize recent apps if enabled
        if (settings.recentAppsTaskbarEnabled) {
            overlay?.initializeRecentApps(windowAnalyzer.getLauncherPackages())
        }
        checkImeVisibility()

        // 배터리 모니터링 시작
        startBatteryMonitoring()

        // 현재 연결된 키보드 확인 및 방향 고정 적용
        checkAndApplyOrientationLock()

        Log.i(TAG, "Service fully initialized")
    }

    private fun initializeComponents() {
        settings = SettingsManager.getInstance(this)
        windowAnalyzer = WindowAnalyzer(this)
        keyEventHandler = KeyEventHandler(this)
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        isScreenInteractive = powerManager.isInteractive
    }

    private fun setupServiceInfo() {
        try {
            val info = serviceInfo

            // Ensure key event filtering is explicitly enabled
            info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS

            // Verify key event filtering is enabled
            val hasFlag = info.flags and AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS != 0
            val hasCapability = info.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_REQUEST_FILTER_KEY_EVENTS != 0

            if (hasFlag && hasCapability) {
                Log.i(TAG, "Key event filtering is ENABLED (flag=true, capability=true)")
            } else {
                Log.w(TAG, "Key event filtering issue - flag=$hasFlag, capability=$hasCapability")
                if (!hasCapability) {
                    Log.w(TAG, "Missing CAPABILITY_CAN_REQUEST_FILTER_KEY_EVENTS - ensure canRequestFilterKeyEvents=true in XML")
                }
            }

            Log.d(TAG, "Service flags: ${info.flags}")
            Log.d(TAG, "Service capabilities: ${info.capabilities}")
            Log.d(TAG, "Event types: ${info.eventTypes}")
            Log.i(TAG, "Keyboard shortcut handling initialized")

            serviceInfo = info
        } catch (e: Exception) {
            Log.w(TAG, "Could not update serviceInfo flags", e)
        }
    }

    private fun registerReceivers() {
        val settingsFilter = IntentFilter().apply {
            addAction(Constants.Action.SETTINGS_CHANGED)
            addAction(Constants.Action.RELOAD_BACKGROUND)
            addAction(Constants.Action.UPDATE_BUTTON_COLORS)
            addAction(ACTION_APPLY_ORIENTATION_LOCK)
            addAction(ACTION_REMOVE_ORIENTATION_LOCK)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(settingsReceiver, settingsFilter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(settingsReceiver, settingsFilter)
        }

        val screenStateFilter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenStateReceiver, screenStateFilter)

        val bluetoothFilter = IntentFilter().apply {
            addAction(android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        registerReceiver(bluetoothReceiver, bluetoothFilter)

        // 런처 상태 연동 브로드캐스트
        val launcherStateFilter = IntentFilter().apply {
            addAction("com.minsoo.ultranavbar.INTEGRATION_LAUNCHER_STATE")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(launcherStateReceiver, launcherStateFilter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(launcherStateReceiver, launcherStateFilter)
        }
    }

    override fun onDestroy() {
        Log.i(TAG, "Service destroyed")
        instance = null

        // SplitScreenHelper 참조 해제
        SplitScreenHelper.setAccessibilityService(null)

        cancelPendingTasks()
        handler.removeCallbacksAndMessages(null)  // 모든 대기 콜백 제거
        unregisterReceivers()
        destroyOverlay()
        removeOrientationLockOverlay()
        stopBatteryMonitoring()

        super.onDestroy()
    }

    private fun cancelPendingTasks() {
        pendingStateCheck?.let { handler.removeCallbacks(it) }
        pendingStateCheck = null

        pendingHomeReturnProbe?.let { handler.removeCallbacks(it) }
        pendingHomeReturnProbe = null

        pendingBackExitPreviewProbe?.let { handler.removeCallbacks(it) }
        pendingBackExitPreviewProbe = null

        unlockFadeRunnable?.let { handler.removeCallbacks(it) }
        unlockFadeRunnable = null

        pendingRecentsEventCloseRunnable?.let { handler.removeCallbacks(it) }
        pendingRecentsEventCloseRunnable = null

        windowRecoveryRunnable?.let { handler.removeCallbacks(it) }
        windowRecoveryRunnable = null

        cancelDisabledAppRecoveryCheck()

        stopFullscreenPolling()
    }

    private fun unregisterReceivers() {
        try {
            unregisterReceiver(settingsReceiver)
            unregisterReceiver(screenStateReceiver)
            unregisterReceiver(bluetoothReceiver)
            unregisterReceiver(launcherStateReceiver)
        } catch (e: Exception) {
            Log.w(TAG, "Receiver not registered", e)
        }
    }

    // ===== 설정 변경 =====

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        // configuration.orientation은 이 태블릿에서 신뢰할 수 없으므로
        // 실제 디스플레이 회전 기반으로 방향을 결정
        val actualOrientation = windowAnalyzer.getOrientationFromDisplay()
        val orientationChanged = currentOrientation != actualOrientation
        currentOrientation = actualOrientation

        Log.d(TAG, "Configuration changed: config.orientation=${newConfig.orientation}, actual=$actualOrientation, changed=$orientationChanged")

        // 방향 + 다크 모드를 통합 처리 (비트맵 리로드 1회, 올바른 순서 보장)
        overlay?.handleConfigurationChange(actualOrientation)

        if (orientationChanged) {
            // 화면 회전 시간 기록 (안정화 기간 동안 auto-hide 차단)
            lastOrientationChangeAt = SystemClock.elapsedRealtime()

            windowAnalyzer.calculateNavBarHeight()

            val shouldKeepHiddenAfterRotation =
                windowAnalyzer.shouldAutoHideOverlay(
                    currentPackage = currentPackage,
                    isFullscreen = isFullscreen,
                    isOnHomeScreen = isOnHomeScreen,
                    isWallpaperPreviewVisible = isWallpaperPreviewVisible
                )

            if (shouldKeepHiddenAfterRotation) {
                Log.d(TAG, "Orientation changed while auto-hide should remain active - keeping overlay hidden")
                overlay?.hide(animate = false, showHotspot = false)
            } else {
                // 화면 회전 후 오버레이를 강제로 표시 (숨김 방지)
                overlay?.show(fade = false)
            }

            // 화면 회전 후 일정 시간 후에 상태 재확인
            handler.postDelayed({
                if (instance == null) return@postDelayed
                Log.d(TAG, "Re-checking overlay visibility after orientation change")
                updateOverlayVisibility(forceFade = false)
            }, 200)

            scheduleStateCheck()
        }
    }

    // ===== 접근성 이벤트 =====

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val now = SystemClock.elapsedRealtime()

        // IME 포커스 추적
        handleImeFocusEvent(event, now)

        // 배경화면 미리보기 감지
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val className = event.className?.toString()
            if (className == "com.minsoo.ultranavbar.ui.WallpaperPreviewActivity") {
                isWallpaperPreviewVisible = true
                overlay?.hide(animate = false)
                return
            } else if (isWallpaperPreviewVisible) {
                isWallpaperPreviewVisible = false
                updateOverlayVisibility(forceFade = true)
            }
        }

        // 이벤트 유형별 처리
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowStateChanged(event)
                scheduleStateCheck()
            }
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                handleNotificationStateChanged(event)
            }
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> {
                handleWindowsLaunchHint()
                scheduleStateCheck()
            }
            AccessibilityEvent.TYPE_VIEW_FOCUSED,
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED -> {
                scheduleStateCheck()
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                handleNonLauncherContentLaunchHint(event)
                scheduleStateCheck()
            }
        }
    }

    private fun handleImeFocusEvent(event: AccessibilityEvent, now: Long) {
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED) {
            val focusedIsTextInput = windowAnalyzer.isTextInputClass(event.className)
            if (focusedIsTextInput) {
                windowAnalyzer.setImeFocusActive(true)
                lastImeEventAt = now
                updateImeVisible(true)
            } else {
                windowAnalyzer.setImeFocusActive(false)
                scheduleStateCheck()
            }
        }

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            lastImeEventAt = now
        }
    }

    private fun handleNonLauncherContentLaunchHint(event: AccessibilityEvent) {
        if (!isOnHomeScreen || isRecentsVisible) return
        if (isNotificationPanelOpen || isQuickSettingsOpen || isImeVisible) return

        val packageName = event.packageName?.toString() ?: return
        val className = event.className?.toString().orEmpty()

        if (isImePackageOrWindow(packageName, className)) return
        if (isLauncherLikeHintClass(className)) return

        if (packageName == this.packageName || packageName == "com.android.systemui") return
        if (windowAnalyzer.isLauncherPackage(packageName)) return
        if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE) return

        val elapsedFromHomeAction = SystemClock.elapsedRealtime() - lastHomeActionAt
        if (
            packageName == lastHomeActionSourcePackage &&
            elapsedFromHomeAction in 0 until HOME_ACTION_OVERLAY_GUARD_MS
        ) {
            return
        }

        val genericClassSignal =
            className.isBlank() ||
                className == "android.view.View" ||
                className == "android.view.ViewGroup" ||
                className == "android.widget.FrameLayout"
        val classLooksActivity = className.startsWith(packageName)

        if (!genericClassSignal && !classLooksActivity) return

        val windowList = windows.toList()
        val hasVisibleNonLauncherApp = windowAnalyzer.hasVisibleNonLauncherAppWindow(
            windowList,
            this.packageName
        )

        // Ignore generic TYPE_WINDOW_CONTENT_CHANGED events coming from widgets
        // (e.g. clock widget updates) when we're on the home screen and the
        // top visible window is still the launcher and there are no visible
        // non-launcher app windows. These should not be treated as app launch
        // hints to avoid flicker/false positives.
        val topWindow = windowAnalyzer.getTopApplicationWindow(windowList)
        if (genericClassSignal && !hasVisibleNonLauncherApp &&
            (topWindow == null || windowAnalyzer.isLauncherPackage(topWindow.packageName))
        ) {
            Log.d(TAG, "Ignoring home widget content event: pkg=$packageName (top=${topWindow?.packageName})")
            return
        }

        maybeAbortHomeEntryTransitionForLaunchHint(
            packageName = packageName,
            className = className,
            windowList = windowList,
            root = rootInActiveWindow,
            source = "event_content_hint"
        )

        if (
            handleImmediateAppLaunchTransition(
                packageName = packageName,
                className = className,
                hasVisibleNonLauncherApp = hasVisibleNonLauncherApp,
                windowList = windowList,
                root = rootInActiveWindow,
                source = "event_content_hint"
            )
        ) {
            Log.d(TAG, "Content launch hint accepted: pkg=$packageName, class=$className")
        }
    }

    private fun handleWindowsLaunchHint() {
        if (!isOnHomeScreen || isRecentsVisible) return
        if (isNotificationPanelOpen || isQuickSettingsOpen || isImeVisible) return

        val windowList = windows.toList()
        val topWindow = windowAnalyzer.getTopApplicationWindow(windowList) ?: return
        val packageName = topWindow.packageName
        val className = topWindow.className

        if (packageName.isEmpty()) return
        if (isImePackageOrWindow(packageName, className)) return
        if (isLauncherLikeHintClass(className)) return
        if (packageName == this.packageName || packageName == "com.android.systemui") return
        if (windowAnalyzer.isLauncherPackage(packageName)) return
        if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE && isGoogleLauncherCompanionClass(className)) return

        val elapsedFromHomeAction = SystemClock.elapsedRealtime() - lastHomeActionAt
        if (
            packageName == lastHomeActionSourcePackage &&
            elapsedFromHomeAction in 0 until HOME_ACTION_OVERLAY_GUARD_MS
        ) {
            return
        }

        val hasVisibleNonLauncherApp = windowAnalyzer.hasVisibleNonLauncherAppWindow(
            windowList,
            this.packageName
        )

        maybeAbortHomeEntryTransitionForLaunchHint(
            packageName = packageName,
            className = className,
            windowList = windowList,
            root = rootInActiveWindow,
            source = "windows_hint"
        )

        if (
            handleImmediateAppLaunchTransition(
                packageName = packageName,
                className = className,
                hasVisibleNonLauncherApp = hasVisibleNonLauncherApp,
                windowList = windowList,
                root = rootInActiveWindow,
                source = "windows_hint"
            )
        ) {
            Log.d(TAG, "Windows launch hint accepted: pkg=$packageName, class=$className")
        }
    }

    private fun isImePackageOrWindow(packageName: String, className: String): Boolean {
        val normalizedPackage = packageName.trim()
        val normalizedClass = className.trim()

        if (normalizedPackage.contains("inputmethod", ignoreCase = true)) return true
        if (normalizedPackage.contains("keyboard", ignoreCase = true)) return true
        if (normalizedPackage.contains("latin", ignoreCase = true)) return true

        if (normalizedClass.contains("SoftInputWindow", ignoreCase = true)) return true
        if (normalizedClass.contains("InputMethod", ignoreCase = true)) return true

        return false
    }

    private fun isLauncherLikeHintClass(className: String): Boolean {
        val normalizedClass = className.trim()
        if (normalizedClass.isBlank()) return false
        if (normalizedClass.startsWith("com.android.launcher3")) return true
        if (normalizedClass.startsWith("com.google.android.apps.nexuslauncher")) return true
        val simpleName = normalizedClass.substringAfterLast('.')
        return simpleName.contains("SearchLauncher", ignoreCase = true) ||
            simpleName.contains("LauncherClient", ignoreCase = true) ||
            simpleName.contains("Discover", ignoreCase = true)
    }

    private fun maybeAbortHomeEntryTransitionForLaunchHint(
        packageName: String,
        className: String,
        windowList: List<AccessibilityWindowInfo>,
        root: AccessibilityNodeInfo?,
        source: String
    ) {
        if (!isOnHomeScreen || isRecentsVisible) return
        if (isNotificationPanelOpen || isQuickSettingsOpen || isImeVisible) return
        if (packageName.isEmpty()) return
        if (packageName == this.packageName || packageName == "com.android.systemui") return
        if (isImePackageOrWindow(packageName, className)) return
        if (windowAnalyzer.isLauncherPackage(packageName)) return
        if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE && isGoogleLauncherCompanionClass(className)) return

        val elapsedFromHomeAction = SystemClock.elapsedRealtime() - lastHomeActionAt
        if (
            packageName == lastHomeActionSourcePackage &&
                elapsedFromHomeAction in 0 until HOME_ACTION_STALE_NON_LAUNCHER_MS
        ) {
            return
        }

        if (shouldIgnoreStaleAppEventNearHomeEntry(packageName, className, windowList, root)) return

        overlay?.abortHomeEntryTransitionForLaunchHint(
            packageName = packageName,
            className = className,
            source = source
        )
    }

    private fun handleNotificationStateChanged(event: AccessibilityEvent) {
        val parcelableData = event.parcelableData
        val packageName = event.packageName?.toString()

        // Notification 객체에서 정보 추출
        var notificationKey: String? = null
        var category: String? = null
        var isOngoing = false

        // 알림 제거 이벤트 감지
        val isRemoval = parcelableData == null

        if (parcelableData is android.app.Notification) {
            notificationKey = "${packageName}:${parcelableData.hashCode()}"
            category = parcelableData.category
            isOngoing = (parcelableData.flags and android.app.Notification.FLAG_ONGOING_EVENT) != 0
        }

        Log.d(TAG, "Notification state: pkg=$packageName, key=$notificationKey, category=$category, ongoing=$isOngoing, removal=$isRemoval")

        // NotificationTracker로 새 알림인지 판단
        val isNewNotification = notificationTracker.processNotificationEvent(
            key = notificationKey,
            packageName = packageName,
            category = category,
            isOngoing = isOngoing,
            isRemoval = isRemoval
        )

        // 새 알림이고 확인하지 않은 알림이 있으면 깜빡임 시작
        if (isNewNotification && notificationTracker.hasUnseenNotifications()) {
            overlay?.setNotificationPresent(true)
        }

        // 알림이 제거되었거나 더 이상 미확인 알림이 없으면 깜빡임 중지
        if (isRemoval || !notificationTracker.hasUnseenNotifications()) {
            overlay?.setNotificationPresent(false)
        }
    }

    private fun handleWindowStateChanged(event: AccessibilityEvent) {
        var packageName = event.packageName?.toString() ?: return
        var className = event.className?.toString() ?: ""
        val isRecents = windowAnalyzer.isRecentsClassName(className)

        // 디버깅: 모든 윈도우 상태 변경 로그
        Log.d(TAG, "WindowStateChanged: pkg=$packageName, class=$className")

        // 시스템 펜 설정 화면 차단 및 리다이렉트
        if (shouldBlockSystemPenSettings(packageName, className)) {
            redirectToAppPenSettings()
            return
        }

        updateRecentsState(isRecents, "event")

        // 이 앱의 액티비티가 열리면 홈 화면 상태를 false로 설정 후 리턴
        // 단, 오버레이 윈도우(className이 android.widget.* 등 시스템 뷰)는 무시
        // NavbarApps 패널 등 TYPE_ACCESSIBILITY_OVERLAY는 홈 상태에 영향을 주지 않아야 함
        if (packageName == this.packageName) {
            val isActivity = className.startsWith(packageName)
            if (isActivity) {
                updateHomeScreenState(false, "self_app")

                // self app에서도 currentPackage를 동기화해야
                // 최근 앱 taskbar 노출 조건이 정확히 계산된다.
                val packageChanged = updateForegroundPackage(packageName, "self_app", className)
                if (packageChanged) {
                    handler.post {
                        checkFullscreenState()
                        updateOverlayVisibility()
                    }
                }
            }
            return
        }

        val isSystemUi = packageName == "com.android.systemui"
        if (handleSystemUiState(isSystemUi, isRecents, "event")) {
            return
        }

        val windowList = windows.toList()
        var remappedLauncherCompanion = false
        windowAnalyzer.remapLauncherCompanionPackage(
            packageName = packageName,
            className = className,
            windows = windowList,
            selfPackage = this.packageName
        )?.let { remapped ->
            Log.d(TAG, "Remapped launcher companion surface: $packageName -> $remapped")
            packageName = remapped
            className = ""
            remappedLauncherCompanion = true
        }

        val hasVisibleNonLauncherApp = windowAnalyzer.hasVisibleNonLauncherAppWindow(
            windowList,
            this.packageName
        )
        maybeAbortHomeEntryTransitionForLaunchHint(
            packageName = packageName,
            className = className,
            windowList = windowList,
            root = rootInActiveWindow,
            source = "event_state"
        )
        val (launchFastPackage, launchFastClass) = resolveImmediateLaunchCandidate(
            packageName = packageName,
            className = className,
            windowList = windowList,
            hasVisibleNonLauncherApp = hasVisibleNonLauncherApp
        )

        if (
            handleImmediateAppLaunchTransition(
                packageName = launchFastPackage,
                className = launchFastClass,
                hasVisibleNonLauncherApp = hasVisibleNonLauncherApp,
                windowList = windowList,
                root = rootInActiveWindow,
                source = "event"
            )
        ) {
            return
        }

        if (
            handleImmediateHomeEntryTransition(
                packageName = packageName,
                className = className,
                windowList = windowList,
                root = rootInActiveWindow,
                source = "event"
            )
        ) {
            return
        }

        if (shouldIgnoreGoogleCompanionNearHome(packageName, className, windowList, rootInActiveWindow)) {
            Log.d(TAG, "Ignore Google companion near home (event): class=$className")
            syncLauncherOverlayState(windowList, rootInActiveWindow, "event_google_guard", packageName, className)
            return
        }

        if (shouldIgnoreStaleAppEventNearHomeEntry(packageName, className, windowList, rootInActiveWindow)) {
            Log.d(TAG, "Ignore stale non-launcher near home entry (event): $packageName")
            syncLauncherOverlayState(windowList, rootInActiveWindow, "event_stale_app", packageName, className)
            return
        }

        if (shouldIgnoreStaleNonLauncherAfterHome(packageName)) {
            Log.d(TAG, "Ignore stale non-launcher after HOME (event): $packageName")
            syncLauncherOverlayState(windowList, rootInActiveWindow, "event_stale", packageName, className)
            return
        }

        markNonLauncherEvent(packageName, className)
        if (hasVisibleNonLauncherApp) {
            lastNonLauncherEventAt = SystemClock.elapsedRealtime()
        }

        val suppressHomeForRecentApp = shouldSuppressHomeForRecentApp()
        val isLauncherPackage = windowAnalyzer.isLauncherPackage(packageName)
        val preferLauncherHomeEntry = shouldPreferLauncherHomeEntry(
            isLauncherPackage = isLauncherPackage,
            hasVisibleNonLauncherApp = hasVisibleNonLauncherApp,
            recentsVisible = isRecentsVisible
        )
        val effectiveHasVisibleNonLauncherApp =
            if (preferLauncherHomeEntry) {
                Log.d(TAG, "Prefer launcher home entry despite residual non-launcher window (event)")
                false
            } else {
                hasVisibleNonLauncherApp
            }
        val suppressCompanionForegroundUpdate =
            remappedLauncherCompanion &&
                suppressHomeForRecentApp &&
                currentPackage.isNotEmpty() &&
                !windowAnalyzer.isLauncherPackage(currentPackage)

        val suppressLauncherForegroundUpdate =
            isLauncherPackage &&
                !isOnHomeScreen &&
                !isRecentsVisible &&
                effectiveHasVisibleNonLauncherApp &&
                suppressHomeForRecentApp
        val launcherForegroundStabilizationElapsed =
            getLauncherForegroundSuppressElapsedDuringHomeExitStabilization(
                isLauncherPackage = isLauncherPackage,
                recentsVisible = isRecentsVisible
            )
        val suppressLauncherForegroundDuringHomeExitStabilization =
            launcherForegroundStabilizationElapsed != null

        val packageChanged = if (suppressCompanionForegroundUpdate) {
            Log.d(TAG, "Skip launcher companion foreground update during app launch transition")
            false
        } else if (suppressLauncherForegroundUpdate) {
            Log.d(TAG, "Skip launcher foreground update while non-launcher window is still visible (event)")
            false
        } else if (suppressLauncherForegroundDuringHomeExitStabilization) {
            Log.d(
                TAG,
                "Skip launcher foreground update during home-exit stabilization " +
                    "(event, ${launcherForegroundStabilizationElapsed}ms < ${HOME_EXIT_STABILIZE_MS}ms)"
            )
            false
        } else {
            updateForegroundPackage(packageName, "event", className)
        }

        val hasNonLauncherForeground =
            currentPackage.isNotEmpty() && !windowAnalyzer.isLauncherPackage(currentPackage)
        // 앱→홈 전환: 현재 홈이 아닌 상태에서 런처가 오면 즉시 홈 상태 설정
        // 홈→앱 전환: 최근 비런처 이벤트 직후 런처 companion 신호는 홈 재진입을 억제
        val shouldSuppressHome =
            suppressHomeForRecentApp && (isOnHomeScreen || remappedLauncherCompanion)
        val newOnHomeScreen = isLauncherPackage &&
            !isRecentsVisible &&
            !effectiveHasVisibleNonLauncherApp &&
            !hasNonLauncherForeground &&
            !shouldSuppressHome

        // 이미 홈 화면이고 런처 이벤트인 경우, 잔류 앱 윈도우로 인한 잘못된 홈 이탈 방지
        if (!newOnHomeScreen && isOnHomeScreen && isLauncherPackage && !isRecentsVisible) {
            Log.d(TAG, "Home exit from event suppressed (launcher event, " +
                    "hasNonLauncherApp=$effectiveHasVisibleNonLauncherApp, suppressHome=$shouldSuppressHome, " +
                    "remappedCompanion=$remappedLauncherCompanion)")
        } else {
            val homeStateSource =
                if (!newOnHomeScreen && !isLauncherPackage && !remappedLauncherCompanion) {
                    "event_non_launcher"
                } else {
                    "event"
                }
            updateHomeScreenState(newOnHomeScreen, homeStateSource)
        }

        if (packageChanged) {
            handler.post {
                checkFullscreenState()
                updateOverlayVisibility()
            }
        }

        syncLauncherOverlayState(windowList, rootInActiveWindow, "event", packageName, className)
    }

    private fun syncLauncherOverlayState(
        windowList: List<AccessibilityWindowInfo>,
        root: AccessibilityNodeInfo?,
        source: String,
        hintPackage: String = "",
        hintClassName: String = ""
    ) {
        // 런처 브로드캐스트로 설정된 앱서랍 상태는 일정 시간 동안 창 분석으로 덮어쓰지 않음
        val broadcastElapsed = SystemClock.elapsedRealtime() - lastBroadcastDrawerStateAt
        if (broadcastElapsed in 0 until BROADCAST_DRAWER_STATE_GUARD_MS) {
            Log.d(TAG, "syncLauncherOverlayState skipped ($source): broadcast guard active (${broadcastElapsed}ms)")
            return
        }

        if (isOnHomeScreen) {
            val hasVisibleNonLauncherApp = windowAnalyzer.hasVisibleNonLauncherAppWindow(
                windowList,
                this.packageName
            )
            val normalizedHintPackage = hintPackage.trim()
            val normalizedHintClass = hintClassName.trim()
            val launcherNonHomeHint =
                normalizedHintPackage.isNotEmpty() &&
                    windowAnalyzer.isLauncherNonHomeSurface(normalizedHintPackage, normalizedHintClass)
            val launcherDragHint =
                normalizedHintPackage.isNotEmpty() &&
                    windowAnalyzer.isLauncherDragSurface(normalizedHintPackage, normalizedHintClass)

            var appDrawerOpen = windowAnalyzer.analyzeLauncherOverlayState(windowList, root)
            if (launcherNonHomeHint) {
                appDrawerOpen = true
                Log.d(TAG, "Launcher non-home hint ($source): $normalizedHintPackage/$normalizedHintClass")
            }

            if (appDrawerOpen && hasVisibleNonLauncherApp && !launcherNonHomeHint) {
                Log.d(
                    TAG,
                    "Ignore launcher overlay candidate during app-to-home transition ($source)"
                )
                appDrawerOpen = false
            }

            val homeActionElapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
            if (
                appDrawerOpen &&
                !launcherNonHomeHint &&
                lastHomeActionSourcePackage.isNotEmpty() &&
                homeActionElapsed in 0 until HOME_ACTION_OVERLAY_GUARD_MS
            ) {
                Log.d(
                    TAG,
                    "Ignore launcher overlay candidate near HOME action ($source, ${homeActionElapsed}ms)"
                )
                appDrawerOpen = false
            }

            val homeEntryElapsed = SystemClock.elapsedRealtime() - lastHomeEntryAt
            if (
                appDrawerOpen &&
                !launcherNonHomeHint &&
                homeEntryElapsed < HOME_ENTRY_STABILIZE_MS &&
                shouldSuppressHomeForRecentApp()
            ) {
                Log.d(
                    TAG,
                    "Ignore launcher overlay candidate near home entry ($source, ${homeEntryElapsed}ms)"
                )
                appDrawerOpen = false
            }

            if (isAppDrawerOpen != appDrawerOpen) {
                isAppDrawerOpen = appDrawerOpen
                Log.d(TAG, "App Drawer state ($source): $isAppDrawerOpen")
                overlay?.setAppDrawerState(isAppDrawerOpen)
            }

            val dragDetectedByWindow = windowAnalyzer.analyzeLauncherIconDragState(windowList, root)
            val iconDragActive =
                !hasVisibleNonLauncherApp &&
                    !appDrawerOpen &&
                    (dragDetectedByWindow || launcherDragHint)

            if (launcherDragHint && !dragDetectedByWindow) {
                Log.d(TAG, "Launcher drag hint ($source): $normalizedHintPackage/$normalizedHintClass")
            }

            if (isLauncherIconDragActive != iconDragActive) {
                isLauncherIconDragActive = iconDragActive
                Log.d(TAG, "Launcher icon drag state ($source): $isLauncherIconDragActive")
                overlay?.setLauncherIconDragState(isLauncherIconDragActive)
            }
        } else {
            if (isAppDrawerOpen) {
                isAppDrawerOpen = false
                Log.d(TAG, "App Drawer state ($source): false")
                overlay?.setAppDrawerState(false)
            }
            if (isLauncherIconDragActive) {
                isLauncherIconDragActive = false
                Log.d(TAG, "Launcher icon drag state ($source): false")
                overlay?.setLauncherIconDragState(false)
            }
        }
    }

    private fun updateRecentsState(isRecents: Boolean, source: String) {
        if (isRecents) {
            pendingRecentsEventCloseRunnable?.let { handler.removeCallbacks(it) }
            pendingRecentsEventCloseRunnable = null
        } else if (
            source == "event" &&
            isRecentsVisible &&
            windowAnalyzer.isLauncherPackage(currentPackage)
        ) {
            pendingRecentsEventCloseRunnable?.let { handler.removeCallbacks(it) }
            val task = Runnable {
                pendingRecentsEventCloseRunnable = null
                val recentsStillVisible = windowAnalyzer.analyzeRecentsState(windows.toList(), rootInActiveWindow)
                if (recentsStillVisible) {
                    Log.d(TAG, "Recents false (event) ignored after debounce; windows still recents")
                    return@Runnable
                }
                updateRecentsState(false, "event_debounced")
            }
            pendingRecentsEventCloseRunnable = task
            handler.postDelayed(task, RECENTS_EVENT_FALSE_DEBOUNCE_MS)
            Log.d(TAG, "Recents false (event) deferred for stabilization")
            return
        } else {
            pendingRecentsEventCloseRunnable?.let { handler.removeCallbacks(it) }
            pendingRecentsEventCloseRunnable = null
        }

        val wasRecentsVisible = isRecentsVisible
        if (isRecentsVisible != isRecents) {
            isRecentsVisible = isRecents
            Log.d(TAG, "Recents state ($source): $isRecentsVisible")
            overlay?.setRecentsState(isRecents)

            // 최근 앱 화면이 닫힐 때 - 분할화면 플래그 리셋
            if (wasRecentsVisible && !isRecents) {
                val helperFlag = SplitScreenHelper.wasSplitScreenUsedAndReset()
                if (wasSplitScreenUsed || helperFlag) {
                    val splitLikelyActive = isSplitScreenMode ||
                        SplitScreenHelper.isSplitScreenActive() ||
                        SplitScreenHelper.isSplitActiveOrRecent(4000) ||
                        SplitScreenHelper.isInRecoveryGracePeriod()
                    if (splitLikelyActive) {
                        Log.d(TAG, "Recents closed but split still active; skipping cleanup")
                    } else {
                        Log.d(TAG, "Recents closed after split screen, resetting flags")
                        cleanSplitScreenStacks()
                        wasSplitScreenUsed = false
                    }
                }
            }
        }
    }

    /**
     * 분할화면 스택 정리
     *
     * 참고: Android 12+에서 'am stack remove-all-secondary-split-stacks' 명령어가
     * 제거되어 더 이상 사용할 수 없음. 대신 빈 split-screen 태스크를 개별적으로 정리하거나,
     */
    private fun cleanSplitScreenStacks() {
        Log.d(TAG, "Split screen cleanup: resetting all state flags")
        SplitScreenHelper.forceResetSplitScreenState()
        emptySplitSince = 0L
        lastSplitRecoveryAt = 0L
    }

    // 복구 체크는 더 이상 사용하지 않음 - 분할화면 종료 시 즉시 복구
    private fun scheduleWindowRecoveryCheck() {
        // 비활성화됨
    }

    private fun updateHomeScreenState(isHome: Boolean, source: String) {
        if (isOnHomeScreen == isHome) return

        val now = SystemClock.elapsedRealtime()
        val homeElapsed = now - lastHomeEntryAt
        val nonLauncherExitSignal =
            source == "event_non_launcher" || source == "windows_non_launcher"
        val bypassHomeExitStabilization =
            nonLauncherExitSignal && homeElapsed >= HOME_ENTRY_STABILIZE_MS

        // 홈 진입 안정화: 홈에 진입한 직후 false 이벤트 무시
        if (!isHome && isOnHomeScreen) {
            if (!bypassHomeExitStabilization && homeElapsed < HOME_ENTRY_STABILIZE_MS) {
                val reason = if (nonLauncherExitSignal) {
                    "non-launcher stale"
                } else {
                    "stabilizing"
                }
                Log.d(TAG, "Home exit ignored ($reason, ${homeElapsed}ms < ${HOME_ENTRY_STABILIZE_MS}ms)")
                return
            }
        }

        // 홈 이탈 안정화: 홈을 떠난 직후 windows 소스의 잘못된 홈 재진입 방지
        if (isHome && !isOnHomeScreen && source == "windows") {
            val elapsed = now - lastHomeExitAt
            if (elapsed < HOME_EXIT_STABILIZE_MS) {
                Log.d(TAG, "Home re-entry from windows ignored (stabilizing, ${elapsed}ms < ${HOME_EXIT_STABILIZE_MS}ms)")
                return
            }
        }

        if (isHome && !isOnHomeScreen) {
            lastHomeEntryAt = now
        }
        if (!isHome && isOnHomeScreen) {
            lastHomeExitAt = now
        }

        isOnHomeScreen = isHome
        Log.d(TAG, "Home screen state ($source): $isOnHomeScreen")
        overlay?.setHomeScreenState(isOnHomeScreen)
    }

    private fun markNonLauncherEvent(packageName: String, className: String? = null) {
        if (packageName.isEmpty()) return
        if (packageName == this.packageName) return
        if (packageName == "com.android.systemui") return
        if (windowAnalyzer.isLauncherPackage(packageName)) return
        val now = SystemClock.elapsedRealtime()
        lastNonLauncherEventAt = now
        lastNonLauncherPackage = packageName
        lastNonLauncherPackageAt = now
        val normalizedClass = className?.takeIf { it.isNotBlank() }?.let {
            if (it.startsWith(".")) packageName + it else it
        }?.takeIf { it.startsWith(packageName) }
        if (!normalizedClass.isNullOrEmpty()) {
            lastNonLauncherClassName = normalizedClass
            lastNonLauncherClassAt = now
        }
    }

    private fun shouldSuppressHomeForRecentApp(): Boolean {
        val elapsed = SystemClock.elapsedRealtime() - lastNonLauncherEventAt
        return elapsed < HOME_RECENT_APP_SUPPRESS_MS
    }

    private fun shouldIgnoreStaleNonLauncherAfterHome(packageName: String): Boolean {
        if (!isOnHomeScreen || isRecentsVisible) return false
        if (packageName.isEmpty()) return false
        if (packageName == this.packageName || packageName == "com.android.systemui") return false
        if (windowAnalyzer.isLauncherPackage(packageName)) return false
        if (currentPackage.isNotEmpty() && !windowAnalyzer.isLauncherPackage(currentPackage)) return false

        val sourcePackage = lastHomeActionSourcePackage
        if (sourcePackage.isEmpty() || packageName != sourcePackage) return false

        val elapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
        return elapsed in 0 until HOME_ACTION_STALE_NON_LAUNCHER_MS
    }

    private fun shouldIgnoreGoogleCompanionNearHome(
        packageName: String,
        className: String,
        windowList: List<AccessibilityWindowInfo>,
        root: AccessibilityNodeInfo?
    ): Boolean {
        if (packageName != GOOGLE_QUICKSEARCHBOX_PACKAGE) return false
        if (!isOnHomeScreen || isRecentsVisible) return false
        if (!isGoogleLauncherCompanionClass(className)) return false

        val hasVisibleNonLauncherApp =
            windowAnalyzer.hasVisibleNonLauncherAppWindow(windowList, this.packageName)
        if (hasVisibleNonLauncherApp) return false

        val now = SystemClock.elapsedRealtime()
        val homeEntryElapsed = now - lastHomeEntryAt
        val nearHomeEntry =
            homeEntryElapsed in 0 until HOME_RECENT_APP_SUPPRESS_MS && shouldSuppressHomeForRecentApp()

        val homeActionElapsed = now - lastHomeActionAt
        val nearHomeAction =
            lastHomeActionSourcePackage.isNotEmpty() &&
                homeActionElapsed in 0 until HOME_ACTION_OVERLAY_GUARD_MS

        if (!nearHomeEntry && !nearHomeAction) return false

        // 홈 진입 직후 런처 companion 노이즈를 앱 전환으로 오인하지 않도록 무시
        return true
    }

    private fun isGoogleLauncherCompanionClass(className: String): Boolean {
        val cls = className.trim()
        if (cls.isBlank()) return true
        if (cls == "android.widget.FrameLayout") return true
        if (cls == "android.widget.LinearLayout") return true
        if (cls == "android.widget.ScrollView") return true
        if (cls.startsWith("android.view.")) return true

        val simpleName = cls.substringAfterLast('.')
        return simpleName.contains("SearchLauncher", ignoreCase = true) ||
            simpleName.contains("LauncherClient", ignoreCase = true) ||
            simpleName.contains("Discover", ignoreCase = true)
    }

    private fun shouldIgnoreStaleAppEventNearHomeEntry(
        packageName: String,
        className: String,
        windowList: List<AccessibilityWindowInfo>,
        root: AccessibilityNodeInfo?
    ): Boolean {
        if (!isOnHomeScreen || isRecentsVisible) return false
        if (packageName.isEmpty()) return false
        if (packageName == this.packageName || packageName == "com.android.systemui") return false
        if (windowAnalyzer.isLauncherPackage(packageName)) return false

        val hasVisibleNonLauncherApp =
            windowAnalyzer.hasVisibleNonLauncherAppWindow(windowList, this.packageName)
        if (hasVisibleNonLauncherApp) return false

        val normalizedClass = className.trim()
        val genericClassSignal =
            normalizedClass.isBlank() ||
                normalizedClass == "android.view.View" ||
                normalizedClass == "android.view.ViewGroup" ||
                normalizedClass == "android.widget.FrameLayout"
        if (!genericClassSignal) return false

        val entryElapsed = SystemClock.elapsedRealtime() - lastHomeEntryAt
        if (entryElapsed !in 0 until HOME_ENTRY_STALE_APP_EVENT_GUARD_MS) return false
        if (packageName != lastNonLauncherPackage) return false

        val topWindow = windowAnalyzer.getTopApplicationWindow(windowList)
        val topPackage = topWindow?.packageName ?: root?.packageName?.toString().orEmpty()
        val topClass = topWindow?.className ?: root?.className?.toString().orEmpty()

        val topLauncherLike = windowAnalyzer.isLauncherPackage(topPackage) ||
            (topPackage == GOOGLE_QUICKSEARCHBOX_PACKAGE && isGoogleLauncherCompanionClass(topClass))

        return topLauncherLike
    }

    private fun resolveImmediateLaunchCandidate(
        packageName: String,
        className: String,
        windowList: List<AccessibilityWindowInfo>,
        hasVisibleNonLauncherApp: Boolean
    ): Pair<String, String> {
        if (!hasVisibleNonLauncherApp) return packageName to className
        if (packageName != GOOGLE_QUICKSEARCHBOX_PACKAGE) return packageName to className
        if (!isGoogleLauncherCompanionClass(className)) return packageName to className

        val topNonLauncher = windowAnalyzer.getTopNonLauncherApplicationWindow(
            windows = windowList,
            selfPackage = this.packageName
        ) ?: return packageName to className

        Log.d(
            TAG,
            "Launch fast candidate remap: $packageName/$className -> ${topNonLauncher.packageName}/${topNonLauncher.className}"
        )
        return topNonLauncher.packageName to topNonLauncher.className
    }

    private fun handleImmediateAppLaunchTransition(
        packageName: String,
        className: String,
        hasVisibleNonLauncherApp: Boolean,
        windowList: List<AccessibilityWindowInfo>,
        root: AccessibilityNodeInfo?,
        source: String
    ): Boolean {
        if (!isOnHomeScreen || isRecentsVisible) return false
        if (packageName.isEmpty()) return false
        if (packageName == this.packageName || packageName == "com.android.systemui") return false
        if (isImePackageOrWindow(packageName, className)) return false
        if (windowAnalyzer.isLauncherPackage(packageName)) return false
        if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE && isGoogleLauncherCompanionClass(className)) return false

        val normalizedClass = className.trim()
        val classLooksActivity =
            normalizedClass.isNotBlank() &&
                normalizedClass != "android.view.View" &&
                normalizedClass != "android.view.ViewGroup" &&
                normalizedClass != "android.widget.FrameLayout" &&
                normalizedClass.startsWith(packageName)

        val genericClassSignal =
            normalizedClass.isBlank() ||
                normalizedClass == "android.view.View" ||
                normalizedClass == "android.view.ViewGroup" ||
                normalizedClass == "android.widget.FrameLayout"

        val staleNearHomeEntry =
            shouldIgnoreStaleAppEventNearHomeEntry(packageName, className, windowList, root)
        val recentHomeActionElapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
        val likelyStaleFromLastHomeSource =
            packageName == lastHomeActionSourcePackage &&
                recentHomeActionElapsed in 0 until HOME_ACTION_STALE_NON_LAUNCHER_MS
        val genericLaunchSignal =
            genericClassSignal && !staleNearHomeEntry && !likelyStaleFromLastHomeSource

        if (!classLooksActivity && !hasVisibleNonLauncherApp && !genericLaunchSignal) return false

        markNonLauncherEvent(packageName, className)

        val packageChanged = updateForegroundPackage(packageName, "${source}_launch_fast", className)
        updateHomeScreenState(false, "${source}_launch_fast")
        syncLauncherOverlayState(windowList, root, "${source}_launch_fast", packageName, className)

        if (packageChanged) {
            if (source == "event") {
                handler.post {
                    checkFullscreenState()
                    updateOverlayVisibility()
                }
            } else {
                updateOverlayVisibility()
            }
        }

        Log.d(TAG, "Immediate app launch transition ($source): $packageName")
        return true
    }

    private fun handleImmediateHomeEntryTransition(
        packageName: String,
        className: String,
        windowList: List<AccessibilityWindowInfo>,
        root: AccessibilityNodeInfo?,
        source: String
    ): Boolean {
        if (isOnHomeScreen || isRecentsVisible) return false

        val isLauncherCompanion =
            packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE &&
                isGoogleLauncherCompanionClass(className)
        val launcherLikePackage = windowAnalyzer.isLauncherPackage(packageName) || isLauncherCompanion
        if (!launcherLikePackage) return false

        val elapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
        if (elapsed !in 0 until HOME_ACTION_FAST_HOME_ENTRY_MS) return false
        if (lastHomeActionSourcePackage.isEmpty()) return false

        val normalizedClass = className.trim()
        val launcherClassLike =
            normalizedClass.isBlank() ||
                normalizedClass.contains("SearchLauncher", ignoreCase = true) ||
                normalizedClass.contains("Launcher", ignoreCase = true) ||
                normalizedClass.startsWith("com.android.launcher3")
        if (!launcherClassLike) return false

        val effectivePackage =
            if (isLauncherCompanion && !windowAnalyzer.isLauncherPackage(packageName)) {
                windowAnalyzer.getLauncherPackages().firstOrNull() ?: packageName
            } else {
                packageName
            }

        val packageChanged = updateForegroundPackage(effectivePackage, "${source}_home_fast", className)
        updateHomeScreenState(true, "${source}_home_fast")
        syncLauncherOverlayState(windowList, root, "${source}_home_fast", packageName, className)

        if (packageChanged) {
            if (source == "event") {
                handler.post {
                    checkFullscreenState()
                    updateOverlayVisibility()
                }
            } else {
                updateOverlayVisibility()
            }
        }

        Log.d(TAG, "Immediate home entry transition ($source): $effectivePackage")
        return true
    }

    private fun shouldPreferLauncherHomeEntry(
        isLauncherPackage: Boolean,
        hasVisibleNonLauncherApp: Boolean,
        recentsVisible: Boolean
    ): Boolean {
        if (!isLauncherPackage) return false
        if (isOnHomeScreen || recentsVisible) return false
        if (!hasVisibleNonLauncherApp) return false

        val elapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
        if (elapsed !in 0 until HOME_ACTION_FAST_HOME_ENTRY_MS) return false

        // HOME 버튼 직후 런처가 올라오면 잔류 앱 윈도우보다 홈 진입을 우선한다.
        return true
    }

    private fun getLauncherForegroundSuppressElapsedDuringHomeExitStabilization(
        isLauncherPackage: Boolean,
        recentsVisible: Boolean
    ): Long? {
        if (!isLauncherPackage) return null
        if (isOnHomeScreen || recentsVisible) return null
        if (currentPackage.isEmpty() || windowAnalyzer.isLauncherPackage(currentPackage)) return null

        val elapsed = SystemClock.elapsedRealtime() - lastHomeExitAt
        if (elapsed !in 0 until HOME_EXIT_STABILIZE_MS) return null

        return elapsed
    }

    private fun updateForegroundPackage(
        packageName: String,
        source: String,
        className: String? = null
    ): Boolean {
        if (isImePackageOrWindow(packageName, className.orEmpty())) {
            return false
        }

        val now = SystemClock.elapsedRealtime()
        val normalizedClass = className?.takeIf { it.isNotBlank() }?.let {
            if (it.startsWith(".")) packageName + it else it
        }?.takeIf { it.startsWith(packageName) }

        if (currentPackage == packageName) {
            if (!normalizedClass.isNullOrEmpty()) {
                currentClassName = normalizedClass
                currentClassNameAt = now
            }
            if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE) {
                overlay?.setForegroundPackage(packageName, className ?: "")
            }
            return false
        }

        val previousPackage = currentPackage
        currentPackage = packageName
        if (!normalizedClass.isNullOrEmpty()) {
            currentClassName = normalizedClass
            currentClassNameAt = now
        } else {
            currentClassName = ""
            currentClassNameAt = 0
        }
        Log.d(TAG, "Foreground app ($source): $packageName")

        // 앱 전환 시 키보드 수정자 키 상태 초기화 (stuck modifier 방지)
        keyEventHandler.resetModifiers()

        val wasDisabled = previousPackage.isNotEmpty() && settings.isAppDisabled(previousPackage)
        val isDisabled = settings.isAppDisabled(packageName)
        if (wasDisabled || isDisabled) {
            Log.d(TAG, "Disabled app transition: wasDisabled=$wasDisabled, isDisabled=$isDisabled")
        }

        val disabledHideElapsed = now - lastDisabledAppHideAt
        val shouldRecoverHomeFromDisabled =
            !isDisabled &&
            !isRecentsVisible &&
            !isOnHomeScreen &&
            windowAnalyzer.isLauncherPackage(packageName) &&
            disabledHideElapsed in 1..DISABLED_HOME_RECOVERY_WINDOW_MS
        if (shouldRecoverHomeFromDisabled) {
            Log.d(TAG, "Disabled-home recovery: forcing home state (elapsed=${disabledHideElapsed}ms)")
            updateHomeScreenState(true, "disabled_recovery")
            lastDisabledAppHideAt = 0L
        }

        overlay?.setForegroundPackage(packageName, className ?: "")
        return true
    }

    /**
     * 분할화면용 포그라운드 패키지 해석
     * - 런처/시스템 제외
     * - 윈도우 루트 기반 폴백
     * - 최근 비런처 앱 캐시 사용
     */
    fun resolveForegroundPackageForSplit(
        windowList: List<AccessibilityWindowInfo> = windows.toList()
    ): String {
        val now = SystemClock.elapsedRealtime()
        val top = windowAnalyzer.getTopApplicationWindow(windowList)
        var candidate = top?.packageName ?: ""
        if (candidate == packageName || candidate == "com.android.systemui") {
            candidate = ""
        }
        if (candidate.isNotEmpty() && windowAnalyzer.isLauncherPackage(candidate)) {
            candidate = ""
        }

        val fallbackPkg = windowList.firstNotNullOfOrNull { window ->
            if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION) return@firstNotNullOfOrNull null
            val root = try { window.root } catch (e: Exception) { null }
            val pkg = root?.packageName?.toString()
            val className = root?.className?.toString()
            root?.recycle()
            if (pkg.isNullOrEmpty()) return@firstNotNullOfOrNull null
            if (pkg == packageName || pkg == "com.android.systemui") return@firstNotNullOfOrNull null
            if (windowAnalyzer.isLauncherPackage(pkg) || windowAnalyzer.isRecentsClassName(className ?: "")) {
                return@firstNotNullOfOrNull null
            }
            pkg
        }
        if (!fallbackPkg.isNullOrEmpty()) {
            return fallbackPkg
        }

        if (lastNonLauncherPackage.isNotEmpty() &&
            now - lastNonLauncherPackageAt < SPLIT_FOREGROUND_STALE_MS
        ) {
            return lastNonLauncherPackage
        }

        return candidate
    }

    fun resolveForegroundClassForSplit(packageName: String): String {
        if (packageName.isEmpty()) return ""
        val now = SystemClock.elapsedRealtime()
        if (packageName == lastNonLauncherPackage &&
            lastNonLauncherClassName.isNotEmpty() &&
            now - lastNonLauncherClassAt < SPLIT_FOREGROUND_STALE_MS
        ) {
            return lastNonLauncherClassName
        }
        if (packageName == currentPackage &&
            currentClassName.isNotEmpty() &&
            now - currentClassNameAt < SPLIT_FOREGROUND_STALE_MS
        ) {
            return currentClassName
        }
        return ""
    }

    data class SplitLaunchContext(
        val currentPackage: String,
        val currentClassName: String,
        val isOnHomeScreen: Boolean,
        val isRecentsVisible: Boolean,
        val hasVisibleNonLauncherApp: Boolean,
        val isSplitScreenMode: Boolean
    )

    fun getSplitLaunchContext(): SplitLaunchContext {
        val windowList = windows.toList()
        val hasVisibleNonLauncher = windowAnalyzer.hasVisibleNonLauncherAppWindow(windowList, packageName)
        val current = resolveForegroundPackageForSplit(windowList)
        val currentClassName = resolveForegroundClassForSplit(current)
        return SplitLaunchContext(
            currentPackage = current,
            currentClassName = currentClassName,
            isOnHomeScreen = isOnHomeScreen,
            isRecentsVisible = isRecentsVisible,
            hasVisibleNonLauncherApp = hasVisibleNonLauncher,
            isSplitScreenMode = isSplitScreenMode
        )
    }

    fun isRecentsVisibleForSplit(): Boolean = isRecentsVisible

    fun isOnHomeScreenForSplit(): Boolean = isOnHomeScreen

    fun isLauncherPackageForOverlay(packageName: String): Boolean {
        if (packageName.isBlank()) return false
        return windowAnalyzer.isLauncherPackage(packageName)
    }

    fun isLauncherTopForSplit(): Boolean {
        val windowList = windows.toList()
        val top = windowAnalyzer.getTopApplicationWindow(windowList) ?: return false
        return windowAnalyzer.isLauncherPackage(top.packageName) ||
            windowAnalyzer.isRecentsClassName(top.className)
    }

    fun getLauncherWindowPackageForSplit(): String? {
        val windowList = windows.toList()
        val top = windowAnalyzer.getTopApplicationWindow(windowList)
        if (top != null) {
            val pkg = top.packageName
            if (windowAnalyzer.isLauncherPackage(pkg) ||
                windowAnalyzer.isRecentsClassName(top.className)
            ) {
                return pkg
            }
        }

        for (window in windowList) {
            if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val root = try { window.root } catch (e: Exception) { null } ?: continue
            val pkg = root.packageName?.toString()
            val className = root.className?.toString() ?: ""
            root.recycle()
            if (pkg.isNullOrEmpty()) continue
            if (windowAnalyzer.isLauncherPackage(pkg) || windowAnalyzer.isRecentsClassName(className)) {
                return pkg
            }
        }
        return null
    }

    fun getVisibleLauncherPackagesForSplit(): List<String> {
        val windowList = windows.toList()
        val candidates = mutableMapOf<String, Int>()
        for (window in windowList) {
            if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val root = try { window.root } catch (e: Exception) { null } ?: continue
            val pkg = root.packageName?.toString()
            val className = root.className?.toString()
            root.recycle()
            if (pkg.isNullOrEmpty()) continue

            val title = try { window.title?.toString() } catch (e: Exception) { null }
            val isLauncherLike = windowAnalyzer.isLauncherPackage(pkg) ||
                windowAnalyzer.isRecentsClassName(className ?: "") ||
                (!title.isNullOrEmpty() && windowAnalyzer.isRecentsClassName(title))
            if (!isLauncherLike) continue

            val layer = window.layer
            val prevLayer = candidates[pkg]
            if (prevLayer == null || layer > prevLayer) {
                candidates[pkg] = layer
            }
        }
        return candidates.entries
            .sortedByDescending { it.value }
            .map { it.key }
    }

    fun isSplitSelectionVisibleForSplit(): Boolean {
        return windowAnalyzer.analyzeSplitSelectionState(windows.toList(), packageName)
    }

    fun hasVisibleNonLauncherAppForSplit(): Boolean {
        return windowAnalyzer.hasVisibleNonLauncherAppWindow(windows.toList(), packageName)
    }

    fun isSelfAppVisibleForSplit(): Boolean {
        val windowList = try { windows.toList() } catch (e: Exception) { return false }
        for (window in windowList) {
            if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val root = try { window.root } catch (e: Exception) { null }
            val pkg = root?.packageName?.toString()
            root?.recycle()
            if (pkg == packageName) return true
        }
        return false
    }

    private fun handleSystemUiState(isSystemUi: Boolean, isRecents: Boolean, source: String): Boolean {
        if (!isSystemUi) return false
        if (isRecents && isOnHomeScreen) {
            updateHomeScreenState(false, source)
        }
        return true
    }

    private fun scheduleStateCheck() {
        pendingStateCheck?.let { handler.removeCallbacks(it) }
        pendingStateCheck = Runnable {
            if (instance == null) return@Runnable
            checkFullscreenState()
            checkNotificationPanelState()
            checkQuickSettingsState()
            checkImeVisibility()
            checkSplitScreenState()  // 분할화면 상태 체크 추가
            updateHomeAndRecentsFromWindows()
            overlay?.ensureOrientationSync()
        }
        handler.postDelayed(pendingStateCheck!!, Constants.Timing.STATE_CHECK_DELAY_MS)
    }

    /**
     * 분할화면 상태 감지 및 복구 처리
     * 분할화면 종료 후 유효한 윈도우가 없으면 자동으로 홈 화면으로 이동
     */
    private fun checkSplitScreenState() {
        val windowList = windows.toList()
        val wasInSplitScreen = isSplitScreenMode

        val displayMetrics = resources.displayMetrics
        val screenHeight = displayMetrics.heightPixels
        val screenWidth = displayMetrics.widthPixels
        val distinctPackages = mutableSetOf<String>()
        var hasSmallWindow = false
        // 작은 창이 리사이즈 불가능한 앱에서만 발생했는지 추적
        var smallWindowFromResizableApp = false

        for (window in windowList) {
            if (window.type != android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val bounds = android.graphics.Rect()
            try {
                window.getBoundsInScreen(bounds)
            } catch (e: Exception) {
                continue
            }
            if (bounds.width() <= 0 || bounds.height() <= 0) continue

            val root = try { window.root } catch (e: Exception) { null }
            val pkg = root?.packageName?.toString()
            root?.recycle()
            if (pkg != null &&
                pkg != packageName &&
                pkg != "com.android.systemui" &&
                !windowAnalyzer.isLauncherPackage(pkg)
            ) {
                distinctPackages.add(pkg)
            }

            val widthRatio = bounds.width().toFloat() / screenWidth
            val heightRatio = bounds.height().toFloat() / screenHeight
            if (widthRatio < 0.9f || heightRatio < 0.9f) {
                // 자기 앱의 다이얼로그/팝업 창은 분할화면 판단에서 제외
                // (AlertDialog 등이 전체화면보다 작아서 오탐 발생 방지)
                if (pkg == packageName) continue

                hasSmallWindow = true
                // 작은 창이 리사이즈 가능한 앱에서 왔으면 실제 분할화면일 가능성이 높음
                if (pkg != null && SplitScreenHelper.isResizeableActivity(this, pkg)) {
                    smallWindowFromResizableApp = true
                }
            }
        }

        // 분할화면 상태 감지:
        // - 작은 창이 있되, 리사이즈 가능한 앱에서 발생한 경우에만 분할화면으로 판단
        //   (리사이즈 불가 앱의 다이얼로그/팝업은 분할화면이 아님)
        // - 또는 2개 이상 서로 다른 앱 창이 보이는 경우
        val detectedSplit = (hasSmallWindow && smallWindowFromResizableApp) || distinctPackages.size >= 2

        // 분할 전환 직후에는 런처/리센트 윈도우만 잠깐 보이는 구간이 있어 false로 흔들릴 수 있음.
        // 상태 플래그는 실제 감지값으로 유지하고, cleanup만 잠시 지연한다.
        val shouldDeferCleanup =
            wasInSplitScreen && !detectedSplit && SplitScreenHelper.isSplitActiveOrRecent(2000)
        if (shouldDeferCleanup) {
            Log.d(TAG, "Split false detection observed during stabilization; deferring cleanup")
        }
        isSplitScreenMode = detectedSplit

        // SplitScreenHelper에 상태 동기화
        SplitScreenHelper.setSplitScreenActive(isSplitScreenMode)

        val nonLauncherAppCount = windowList.count { window ->
            if (window.type != android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION) return@count false
            val root = try { window.root } catch (e: Exception) { null } ?: return@count false
            val pkg = root.packageName?.toString()
            root.recycle()
            pkg != null && pkg != packageName && !windowAnalyzer.isLauncherPackage(pkg)
        }

        // 분할화면인데 유효한 앱 창이 없으면 복구 (검은 화면/오류 방지)
        if (isSplitScreenMode && nonLauncherAppCount == 0 && !isRecentsVisible) {
            val now = SystemClock.elapsedRealtime()
            if (emptySplitSince == 0L) {
                emptySplitSince = now
            }
            val emptyElapsed = now - emptySplitSince
            if (!SplitScreenHelper.isInRecoveryGracePeriod() && emptyElapsed > EMPTY_SPLIT_EXIT_MS) {
                if (now - lastSplitRecoveryAt > 1000L) {
                    lastSplitRecoveryAt = now
                    Log.w(TAG, "Split screen empty, exiting to recover")
                    performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
                    SplitScreenHelper.forceResetSplitScreenState()
                    isSplitScreenMode = false
                }
            }
        } else {
            emptySplitSince = 0L
        }

        // 분할화면 진입 시 플래그 설정 (최근 앱 종료 후 복구용)
        if (isSplitScreenMode && !wasInSplitScreen) {
            wasSplitScreenUsed = true
            Log.d(TAG, "Split screen entered, setting recovery flag")
        }

        // 분할화면이 종료되었는지 확인
        if (wasInSplitScreen && !isSplitScreenMode) {
            if (shouldDeferCleanup) {
                Log.d(TAG, "Split screen end cleanup deferred")
            } else {
                Log.d(TAG, "Split screen ended, cleaning split state")
                cleanSplitScreenStacks()
                wasSplitScreenUsed = false

                // 분할화면 종료 후 currentPackage가 비활성화된 앱에 남아있을 수 있음
                // 윈도우 기반으로 포그라운드 패키지를 갱신하고 오버레이 가시성 재확인
                handler.postDelayed({
                    if (instance == null) return@postDelayed
                    Log.d(TAG, "Post-split: refreshing foreground package and visibility")
                    updateHomeAndRecentsFromWindows()
                    updateOverlayVisibility()
                }, 300)
            }
        }

        if (wasInSplitScreen != isSplitScreenMode) {
            Log.d(TAG, "Split screen state changed: $wasInSplitScreen -> $isSplitScreenMode")
        }
    }

    /**
     * 분할화면 종료 후 처리
     * 유효한 터치 가능 윈도우가 없으면 홈 화면으로 자동 이동
     */
    private fun checkFullscreenState() {
        val newFullscreenState = windowAnalyzer.analyzeFullscreenState(windows.toList())

        if (isFullscreen != newFullscreenState) {
            isFullscreen = newFullscreenState
            Log.d(TAG, "Fullscreen state: $isFullscreen, pkg=$currentPackage")

            if (isFullscreen) startFullscreenPolling() else stopFullscreenPolling()
            updateOverlayVisibility()
        } else if (isFullscreen) {
            startFullscreenPolling()
        }
    }

    private fun checkNotificationPanelState() {
        val panelVisible = windowAnalyzer.analyzeNotificationPanelState(windows.toList())

        if (isNotificationPanelOpen != panelVisible) {
            isNotificationPanelOpen = panelVisible
            Log.d(TAG, "Notification panel: $isNotificationPanelOpen")

            // 패널이 열리면 모든 알림을 본 것으로 처리하고 깜빡임 중지
            if (panelVisible) {
                notificationTracker.markAllAsSeen()
                overlay?.setNotificationPresent(false)
            }

            handler.post { updatePanelUiState() }
        }
    }

    private fun checkQuickSettingsState() {
        val qsVisible = windowAnalyzer.analyzeQuickSettingsState(windows.toList(), rootInActiveWindow)

        if (isQuickSettingsOpen != qsVisible) {
            isQuickSettingsOpen = qsVisible
            Log.d(TAG, "Quick settings: $isQuickSettingsOpen")
            handler.post { updatePanelUiState() }
        }
    }

    private fun updatePanelUiState() {
        overlay?.setPanelStates(isNotificationPanelOpen, isQuickSettingsOpen)
    }

    private fun checkImeVisibility() {
        val imeVisible = windowAnalyzer.analyzeImeVisibility(windows.toList())
        updateImeVisible(imeVisible)
    }

    private fun updateImeVisible(visible: Boolean) {
        if (isImeVisible == visible) return
        isImeVisible = visible
        Log.d(TAG, "IME visibility: $isImeVisible")
        handler.post {
            overlay?.setImeVisible(isImeVisible)
            keyEventHandler.setImeVisible(isImeVisible)
        }
    }

    private fun updateHomeAndRecentsFromWindows() {
        val windowList = windows.toList()
        val root = rootInActiveWindow
        val recentsVisible = windowAnalyzer.analyzeRecentsState(windowList, root)
        updateRecentsState(recentsVisible, "windows")

        val topWindow = windowAnalyzer.getTopApplicationWindow(windowList)
        var packageName = topWindow?.packageName ?: ""
        var className = topWindow?.className ?: ""

        if (packageName.isEmpty() || packageName == this.packageName) {
            packageName = root?.packageName?.toString() ?: ""
            className = root?.className?.toString() ?: className
        }

        // 이 앱이 열리면 홈 화면 상태를 false로 설정 후 리턴
        if (packageName.isEmpty() || packageName == this.packageName) {
            if (packageName == this.packageName) {
                updateHomeScreenState(false, "self_app_windows")

                // root의 클래스명이 실제 액티비티일 때만 self foreground를 반영
                // (오버레이 뷰 class는 제외)
                val rootClass = root?.className?.toString() ?: ""
                if (rootClass.startsWith(this.packageName)) {
                    val packageChanged = updateForegroundPackage(this.packageName, "self_app_windows", rootClass)
                    if (packageChanged) {
                        updateOverlayVisibility()
                    }
                }
            }
            return
        }

        val isSystemUi = packageName == "com.android.systemui"
        if (handleSystemUiState(isSystemUi, recentsVisible, "windows")) {
            return
        }

        var remappedLauncherCompanion = false
        windowAnalyzer.remapLauncherCompanionPackage(
            packageName = packageName,
            className = className,
            windows = windowList,
            selfPackage = this.packageName
        )?.let { remapped ->
            Log.d(TAG, "Remapped launcher companion surface (windows): $packageName -> $remapped")
            packageName = remapped
            className = ""
            remappedLauncherCompanion = true
        }

        val hasVisibleNonLauncherApp = windowAnalyzer.hasVisibleNonLauncherAppWindow(
            windowList,
            this.packageName
        )
        maybeAbortHomeEntryTransitionForLaunchHint(
            packageName = packageName,
            className = className,
            windowList = windowList,
            root = root,
            source = "windows_state"
        )
        val (launchFastPackage, launchFastClass) = resolveImmediateLaunchCandidate(
            packageName = packageName,
            className = className,
            windowList = windowList,
            hasVisibleNonLauncherApp = hasVisibleNonLauncherApp
        )

        if (
            handleImmediateAppLaunchTransition(
                packageName = launchFastPackage,
                className = launchFastClass,
                hasVisibleNonLauncherApp = hasVisibleNonLauncherApp,
                windowList = windowList,
                root = root,
                source = "windows"
            )
        ) {
            return
        }

        if (
            handleImmediateHomeEntryTransition(
                packageName = packageName,
                className = className,
                windowList = windowList,
                root = root,
                source = "windows"
            )
        ) {
            return
        }

        if (shouldIgnoreGoogleCompanionNearHome(packageName, className, windowList, root)) {
            Log.d(TAG, "Ignore Google companion near home (windows): class=$className")
            syncLauncherOverlayState(windowList, root, "windows_google_guard", packageName, className)
            return
        }

        if (shouldIgnoreStaleAppEventNearHomeEntry(packageName, className, windowList, root)) {
            Log.d(TAG, "Ignore stale non-launcher near home entry (windows): $packageName")
            syncLauncherOverlayState(windowList, root, "windows_stale_app", packageName, className)
            return
        }

        if (shouldIgnoreStaleNonLauncherAfterHome(packageName)) {
            Log.d(TAG, "Ignore stale non-launcher after HOME (windows): $packageName")
            syncLauncherOverlayState(windowList, root, "windows_stale", packageName, className)
            return
        }

        markNonLauncherEvent(packageName, className)
        if (hasVisibleNonLauncherApp) {
            lastNonLauncherEventAt = SystemClock.elapsedRealtime()
        }

        val suppressHomeForRecentApp = shouldSuppressHomeForRecentApp()
        val isLauncherPackage = windowAnalyzer.isLauncherPackage(packageName)
        val preferLauncherHomeEntry = shouldPreferLauncherHomeEntry(
            isLauncherPackage = isLauncherPackage,
            hasVisibleNonLauncherApp = hasVisibleNonLauncherApp,
            recentsVisible = recentsVisible
        )
        val effectiveHasVisibleNonLauncherApp =
            if (preferLauncherHomeEntry) {
                Log.d(TAG, "Prefer launcher home entry despite residual non-launcher window (windows)")
                false
            } else {
                hasVisibleNonLauncherApp
            }
        val suppressCompanionForegroundUpdate =
            remappedLauncherCompanion &&
                suppressHomeForRecentApp &&
                currentPackage.isNotEmpty() &&
                !windowAnalyzer.isLauncherPackage(currentPackage)

        val suppressLauncherForegroundUpdate =
            isLauncherPackage &&
                !isOnHomeScreen &&
                !recentsVisible &&
                effectiveHasVisibleNonLauncherApp &&
                suppressHomeForRecentApp
        val launcherForegroundStabilizationElapsed =
            getLauncherForegroundSuppressElapsedDuringHomeExitStabilization(
                isLauncherPackage = isLauncherPackage,
                recentsVisible = recentsVisible
            )
        val suppressLauncherForegroundDuringHomeExitStabilization =
            launcherForegroundStabilizationElapsed != null

        val packageChanged = if (suppressCompanionForegroundUpdate) {
            Log.d(TAG, "Skip launcher companion foreground update during app launch transition (windows)")
            false
        } else if (suppressLauncherForegroundUpdate) {
            Log.d(TAG, "Skip launcher foreground update while non-launcher window is still visible (windows)")
            false
        } else if (suppressLauncherForegroundDuringHomeExitStabilization) {
            Log.d(
                TAG,
                "Skip launcher foreground update during home-exit stabilization " +
                    "(windows, ${launcherForegroundStabilizationElapsed}ms < ${HOME_EXIT_STABILIZE_MS}ms)"
            )
            false
        } else {
            updateForegroundPackage(packageName, "windows", className)
        }

        val hasNonLauncherForeground =
            currentPackage.isNotEmpty() && !windowAnalyzer.isLauncherPackage(currentPackage)
        // 앱→홈 전환: 현재 홈이 아닌 상태에서 런처가 오면 즉시 홈 상태 설정
        val shouldSuppressHome =
            suppressHomeForRecentApp && (isOnHomeScreen || remappedLauncherCompanion)
        val newOnHomeScreen = isLauncherPackage &&
            !recentsVisible &&
            !effectiveHasVisibleNonLauncherApp &&
            !hasNonLauncherForeground &&
            !shouldSuppressHome

        // 이미 홈 화면이고 런처가 최상위 윈도우인 경우,
        // 잔류 앱 윈도우(hasVisibleNonLauncherApp)나 최근 앱 이벤트(shouldSuppressHome)로 인한
        // 잘못된 홈 이탈 방지 (플레이스토어 등 일부 앱은 홈 전환 후에도 윈도우가 잔류할 수 있음)
        if (!newOnHomeScreen && isOnHomeScreen && isLauncherPackage && !recentsVisible) {
            Log.d(TAG, "Home exit from windows suppressed (launcher is top, " +
                    "hasNonLauncherApp=$effectiveHasVisibleNonLauncherApp, suppressHome=$shouldSuppressHome, " +
                    "remappedCompanion=$remappedLauncherCompanion)")
        } else {
            val homeStateSource =
                if (!newOnHomeScreen && !isLauncherPackage && !remappedLauncherCompanion) {
                    "windows_non_launcher"
                } else {
                    "windows"
                }
            updateHomeScreenState(newOnHomeScreen, homeStateSource)
        }

        syncLauncherOverlayState(windowList, root, "windows", packageName, className)

        if (packageChanged) {
            updateOverlayVisibility()
        }
    }

    private fun startFullscreenPolling() {
        if (fullscreenPoll != null) return

        fullscreenPoll = object : Runnable {
            override fun run() {
                val before = isFullscreen
                checkFullscreenState()
                if (isFullscreen) {
                    handler.postDelayed(this, Constants.Timing.FULLSCREEN_POLLING_MS)
                } else {
                    stopFullscreenPolling()
                    if (before) {
                        handler.postDelayed({ updateOverlayVisibility() }, Constants.Timing.RECENTS_STATE_DEBOUNCE_MS)
                    }
                }
            }
        }
        handler.postDelayed(fullscreenPoll!!, Constants.Timing.FULLSCREEN_POLLING_MS)
    }

    private fun stopFullscreenPolling() {
        fullscreenPoll?.let { handler.removeCallbacks(it) }
        fullscreenPoll = null
    }

    // ===== 배터리 모니터링 =====

    private fun startBatteryMonitoring() {
        // 30분마다 배터리 체크 (BLE GATT 캐시는 10분 유효)
        batteryMonitorRunnable = object : Runnable {
            override fun run() {
                KeyboardBatteryMonitor.checkBatteryLevels(this@NavBarAccessibilityService)
                handler.postDelayed(this, 1800000L) // 30 minutes
            }
        }
        handler.post(batteryMonitorRunnable!!)
    }

    private fun stopBatteryMonitoring() {
        batteryMonitorRunnable?.let { handler.removeCallbacks(it) }
        batteryMonitorRunnable = null
    }

    // ===== 오버레이 가시성 =====

    private fun updateOverlayVisibility(forceFade: Boolean = false) {
        if (!isScreenInteractive) {
            overlay?.hide(animate = false, showHotspot = false)
            return
        }

        val lockScreenActive = windowAnalyzer.isLockScreenActive()

        // 0. 네비게이션 바 전체 비활성화 체크
        if (!settings.navbarEnabled) {
            Log.d(TAG, "Navbar disabled globally - hiding overlay completely")
            overlay?.hide(animate = false, showHotspot = false)
            return
        }

        // 1. 비활성화된 앱 체크 - 오버레이를 완전히 숨김 (핫스팟 없음, 재호출 불가)
        if (currentPackage.isNotEmpty() && settings.isAppDisabled(currentPackage)) {
            lastDisabledAppHideAt = SystemClock.elapsedRealtime()
            Log.d(TAG, "App disabled: $currentPackage - hiding overlay completely")
            overlay?.hide(animate = false, showHotspot = false)
            // 비활성화 앱 상태에서 이벤트 누락 시 복구를 위해 지연 재확인 예약
            scheduleDisabledAppRecoveryCheck()
            return
        }
        // 비활성화 앱을 벗어났으면 복구 체크 취소
        cancelDisabledAppRecoveryCheck()

        // 1.5. 화면 회전 안정화 기간 동안 숨김 방지
        val orientationChangeElapsed = SystemClock.elapsedRealtime() - lastOrientationChangeAt
        if (orientationChangeElapsed < ORIENTATION_CHANGE_STABILIZE_MS) {
            val shouldAutoHideDuringRotation = windowAnalyzer.shouldAutoHideOverlay(
                currentPackage = currentPackage,
                isFullscreen = isFullscreen,
                isOnHomeScreen = isOnHomeScreen,
                isWallpaperPreviewVisible = isWallpaperPreviewVisible
            )
            if (shouldAutoHideDuringRotation) {
                Log.d(TAG, "Orientation change stabilizing (${orientationChangeElapsed}ms) - keeping overlay hidden")
                overlay?.hide(animate = false, showHotspot = false)
            } else {
                Log.d(TAG, "Orientation change stabilizing (${orientationChangeElapsed}ms) - keeping overlay visible")
                overlay?.show(fade = false)
            }
            return
        }

        // 2. 자동 숨김 체크 - 전체화면 등에서 숨김 (핫스팟으로 재호출 가능)
        val shouldAutoHide = windowAnalyzer.shouldAutoHideOverlay(
            currentPackage = currentPackage,
            isFullscreen = isFullscreen,
            isOnHomeScreen = isOnHomeScreen,
            isWallpaperPreviewVisible = isWallpaperPreviewVisible
        )

        Log.d(TAG, "Update visibility: shouldAutoHide=$shouldAutoHide, lock=$lockScreenActive, pkg=$currentPackage, fullscreen=$isFullscreen")

        if (lockScreenActive && overlay?.hasPendingUnlockFade() == true) {
            Log.d(TAG, "Lock screen active with prepared unlock fade - keeping overlay primed")
            return
        }

        if (lockScreenActive) {
            Log.d(TAG, "Lock screen active - hiding custom overlay")
            fullscreenSlidePendingShow = false
            overlay?.hide(animate = false, showHotspot = false)
            return
        }

        if (shouldHoldOverlayVisibleForCustomHomeAction()) {
            Log.d(TAG, "Keeping overlay visible during custom HOME transition guard")
            val useFullscreenSlide = fullscreenSlidePendingShow
            fullscreenSlidePendingShow = false
            overlay?.show(fade = false, slide = useFullscreenSlide)
            return
        }

        if (shouldAutoHide) {
            val forceFullscreenHide = isFullscreen && !isOnHomeScreen
            if (!forceFullscreenHide && overlay?.canAutoHide() == false) {
                Log.d(TAG, "Auto-hide blocked: recently shown by gesture")
                return
            }
            if (forceFullscreenHide) {
                fullscreenSlidePendingShow = true
                Log.d(TAG, "Fullscreen auto-hide: hiding overlay with slide animation")
                overlay?.hide(animate = true, showHotspot = false, slide = true)
            } else {
                fullscreenSlidePendingShow = false
                overlay?.hide(animate = true, showHotspot = true)
            }
        } else {
            val useFullscreenSlide = fullscreenSlidePendingShow
            fullscreenSlidePendingShow = false
            overlay?.show(fade = forceFade && !useFullscreenSlide, slide = useFullscreenSlide)
        }
    }

    private fun shouldHoldOverlayVisibleForCustomHomeAction(): Boolean {
        if (isOnHomeScreen || isRecentsVisible) return false
        if (lastHomeActionSourcePackage.isEmpty()) return false

        val elapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
        if (elapsed !in 0 until HOME_ACTION_OVERLAY_GUARD_MS) return false

        if (currentPackage.isEmpty()) return true
        if (currentPackage == packageName || currentPackage == "com.android.systemui") return true
        if (isImePackageOrWindow(currentPackage, currentClassName)) return false
        if (windowAnalyzer.isLauncherPackage(currentPackage)) return false

        return true
    }

    /**
     * 비활성화 앱 상태에서 이벤트 누락으로 currentPackage가 갱신되지 않는 경우를 대비한 복구 체크.
     * 주기적으로 윈도우를 확인하여 실제 포그라운드 패키지를 갱신하고 오버레이 가시성을 재평가.
     */
    private fun scheduleDisabledAppRecoveryCheck() {
        // 이미 예약된 경우 중복 예약 방지
        if (disabledAppRecoveryRunnable != null) return

        disabledAppRecoveryRunnable = Runnable {
            disabledAppRecoveryRunnable = null
            if (instance == null) return@Runnable

            val savedPackage = currentPackage
            // 실제 윈도우에서 포그라운드 패키지 갱신
            updateHomeAndRecentsFromWindows()

            if (currentPackage != savedPackage) {
                Log.d(TAG, "Disabled app recovery: package changed $savedPackage -> $currentPackage")
            }
            updateOverlayVisibility()
        }
        handler.postDelayed(disabledAppRecoveryRunnable!!, 500)
    }

    private fun cancelDisabledAppRecoveryCheck() {
        disabledAppRecoveryRunnable?.let {
            handler.removeCallbacks(it)
            disabledAppRecoveryRunnable = null
        }
    }

    // ===== 오버레이 생성/파괴 =====

    private fun createOverlay() {
        if (overlay == null) {
            overlay = NavBarOverlay(this)
            overlay?.create()
            overlay?.updatePanelButtonState(isOpen = false)
        }
    }

    private fun destroyOverlay() {
        overlay?.destroy()
        overlay = null
    }

    // ===== 액션 실행 =====

    fun executeAction(action: NavAction): Boolean {
        if (action == NavAction.NOTIFICATIONS) {
            return if (isNotificationPanelOpen) {
                Log.d(TAG, "Closing notification panel")
                performGlobalAction(GLOBAL_ACTION_BACK)
            } else {
                Log.d(TAG, "Opening notification panel")
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            }
        }

        if (action == NavAction.ASSIST) {
            return executeAssistAction()
        }

        if (action == NavAction.HOME) {
            lastHomeActionAt = SystemClock.elapsedRealtime()
            val sourcePackage = currentPackage
            lastHomeActionSourcePackage =
                sourcePackage.takeIf {
                    it.isNotEmpty() &&
                        it != this.packageName &&
                        it != "com.android.systemui" &&
                        !isImePackageOrWindow(it, currentClassName) &&
                        !windowAnalyzer.isLauncherPackage(it)
                } ?: lastNonLauncherPackage
            Log.d(
                TAG,
                "HOME action marker: source=${lastHomeActionSourcePackage.ifEmpty { "unknown" }}"
            )
        }

        val actionId = action.globalActionId ?: return false
        Log.d(TAG, "Executing action: ${action.name} (id=$actionId)")
        val executed = performGlobalAction(actionId)
        if (executed && action == NavAction.HOME) {
            scheduleHomeReturnProbe()
        }
        if (executed && action == NavAction.BACK) {
            maybeStartBackExitHomePreview()
        }
        return executed
    }

    private fun maybeStartBackExitHomePreview() {
        if (isOnHomeScreen || isRecentsVisible) return

        val packageName = currentPackage
        if (packageName.isEmpty()) return
        if (packageName == this.packageName || packageName == "com.android.systemui") return
        if (windowAnalyzer.isLauncherPackage(packageName)) return

        pendingBackExitPreviewProbe?.let { handler.removeCallbacks(it) }

        val sourcePackage = packageName
        var attempts = 0
        val probe = object : Runnable {
            override fun run() {
                if (instance == null) {
                    pendingBackExitPreviewProbe = null
                    return
                }

                val windowList = windows.toList()
                val root = rootInActiveWindow
                val recentsVisible = windowAnalyzer.analyzeRecentsState(windowList, root)
                if (recentsVisible) {
                    pendingBackExitPreviewProbe = null
                    return
                }

                val topWindow = windowAnalyzer.getTopApplicationWindow(windowList)
                val topPackage = topWindow?.packageName ?: root?.packageName?.toString().orEmpty()
                val topClass = topWindow?.className ?: root?.className?.toString().orEmpty()
                val launcherLikeTop =
                    windowAnalyzer.isLauncherPackage(topPackage) ||
                        (topPackage == GOOGLE_QUICKSEARCHBOX_PACKAGE && isGoogleLauncherCompanionClass(topClass))
                val hasVisibleNonLauncherApp =
                    windowAnalyzer.hasVisibleNonLauncherAppWindow(windowList, this@NavBarAccessibilityService.packageName)

                if (launcherLikeTop && !hasVisibleNonLauncherApp) {
                    overlay?.startBackExitHomePreviewTransition()
                    Log.d(TAG, "Back-exit home preview trigger(single_back_probe): from=$sourcePackage -> top=$topPackage/$topClass")
                    pendingBackExitPreviewProbe = null
                    return
                }

                val shouldStop =
                    topPackage.isNotEmpty() &&
                        topPackage != sourcePackage &&
                        !windowAnalyzer.isLauncherPackage(topPackage)
                if (shouldStop || attempts >= BACK_EXIT_PREVIEW_PROBE_ATTEMPTS - 1) {
                    pendingBackExitPreviewProbe = null
                    return
                }

                attempts++
                handler.postDelayed(this, BACK_EXIT_PREVIEW_PROBE_INTERVAL_MS)
            }
        }

        pendingBackExitPreviewProbe = probe
        handler.postDelayed(probe, BACK_EXIT_PREVIEW_PROBE_INTERVAL_MS)
    }

    private fun scheduleHomeReturnProbe() {
        pendingHomeReturnProbe?.let { handler.removeCallbacks(it) }

        var attempts = 0
        val probe = object : Runnable {
            override fun run() {
                if (instance == null) {
                    pendingHomeReturnProbe = null
                    return
                }

                val elapsed = SystemClock.elapsedRealtime() - lastHomeActionAt
                if (isOnHomeScreen || elapsed > HOME_ACTION_FAST_HOME_ENTRY_MS) {
                    pendingHomeReturnProbe = null
                    return
                }

                updateHomeAndRecentsFromWindows()

                attempts++
                if (!isOnHomeScreen && attempts < 6) {
                    handler.postDelayed(this, 90L)
                } else {
                    pendingHomeReturnProbe = null
                }
            }
        }

        pendingHomeReturnProbe = probe
        handler.postDelayed(probe, 40L)
    }

    private fun executeAssistAction(): Boolean {
        try {
            val customAction = settings.longPressAction
            if (customAction == null) {
                // 음성 어시스턴트 모드로 실행 (마이크 활성화 상태)
                return executeVoiceAssistant()
            } else if (customAction.startsWith("shortcut:")) {
                // 바로가기 실행
                return executeShortcut(customAction.removePrefix("shortcut:"))
            } else {
                // 앱 실행
                val intent = packageManager.getLaunchIntentForPackage(customAction)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    Log.d(TAG, "Executing custom long-press: $customAction")
                    return true
                } else {
                    Log.w(TAG, "Could not launch: $customAction")
                    return false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to execute ASSIST action", e)
            return false
        }
    }

    private fun executeVoiceAssistant(): Boolean {
        // 방법 1: Google Assistant 직접 실행 (하단 팝업 형태)
        try {
            val assistantIntent = Intent(Intent.ACTION_VOICE_COMMAND).apply {
                setPackage("com.google.android.googlequicksearchbox")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (assistantIntent.resolveActivity(packageManager) != null) {
                startActivity(assistantIntent)
                Log.d(TAG, "Executing Google Assistant via ACTION_VOICE_COMMAND")
                return true
            }
        } catch (e: Exception) {
            Log.d(TAG, "Google Assistant ACTION_VOICE_COMMAND failed: ${e.message}")
        }

        // 방법 2: Google Assistant 앱 직접 실행
        try {
            val assistantIntent = Intent(Intent.ACTION_MAIN).apply {
                setClassName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.voiceinteraction.GsaVoiceInteractionService"
                )
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(assistantIntent)
            Log.d(TAG, "Executing Google Assistant via GsaVoiceInteractionService")
            return true
        } catch (e: Exception) {
            Log.d(TAG, "GsaVoiceInteractionService failed: ${e.message}")
        }

        // 방법 3: com.google.android.apps.googleassistant 패키지 실행
        try {
            val assistantIntent = packageManager.getLaunchIntentForPackage("com.google.android.apps.googleassistant")
            if (assistantIntent != null) {
                assistantIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(assistantIntent)
                Log.d(TAG, "Executing Google Assistant app directly")
                return true
            }
        } catch (e: Exception) {
            Log.d(TAG, "Google Assistant app launch failed: ${e.message}")
        }

        // 방법 4: ACTION_VOICE_ASSIST (음성 대기 모드로 실행)
        try {
            val voiceIntent = Intent("android.intent.action.VOICE_ASSIST").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (voiceIntent.resolveActivity(packageManager) != null) {
                startActivity(voiceIntent)
                Log.d(TAG, "Executing voice assistant via VOICE_ASSIST")
                return true
            }
        } catch (e: Exception) {
            Log.d(TAG, "VOICE_ASSIST failed: ${e.message}")
        }

        // 방법 5: ACTION_ASSIST (최후의 폴백)
        try {
            val assistIntent = Intent(Intent.ACTION_ASSIST).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (assistIntent.resolveActivity(packageManager) != null) {
                startActivity(assistIntent)
                Log.d(TAG, "Executing assistant via ACTION_ASSIST (fallback)")
                return true
            }
        } catch (e: Exception) {
            Log.e(TAG, "All assistant methods failed", e)
            return false
        }

        return false
    }

    private fun executeShortcut(shortcutUri: String): Boolean {
        try {
            val intent = Intent.parseUri(shortcutUri, Intent.URI_INTENT_SCHEME).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            Log.d(TAG, "Executing shortcut: $shortcutUri")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to execute shortcut: $shortcutUri", e)
            return false
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Service interrupted")
    }

    /**
     * 시스템 펜 설정 화면을 차단해야 하는지 확인
     */
    private fun shouldBlockSystemPenSettings(packageName: String, className: String): Boolean {
        // 펜 커스텀 기능이 활성화되어 있지 않으면 차단하지 않음
        if (!settings.isPenCustomFunctionEnabled()) {
            return false
        }

        // 설정 앱인지 먼저 확인 (다른 앱은 절대 차단하지 않음)
        val isSettingsApp = packageName == "com.android.settings" ||
                packageName == "com.lge.settings" ||
                packageName.contains("settings", ignoreCase = true)

        if (!isSettingsApp) {
            return false
        }

        // 펜 관련 Activity 감지 (LG, Samsung, 일반 Android)
        val classNameLower = className.lowercase()
        val isPenSettingsActivity = classNameLower.contains("extension") ||
                classNameLower.contains("pen") ||
                classNameLower.contains("stylus") ||
                classNameLower.contains("wacom") ||
                classNameLower.contains("spen") ||
                classNameLower.contains("buttonconfig")

        if (isPenSettingsActivity) {
            Log.d(TAG, "Blocking system pen settings: pkg=$packageName, class=$className")
            return true
        }

        return false
    }

    /**
     * 이 앱의 펜 설정 화면으로 리다이렉트
     */
    private fun redirectToAppPenSettings() {
        try {
            // 먼저 시스템 설정 화면을 닫음
            performGlobalAction(GLOBAL_ACTION_BACK)

            // 이 앱의 메인 화면 열기 (펜 설정 탭)
            handler.postDelayed({
                val intent = Intent(this, com.minsoo.ultranavbar.MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("navigate_to", "pen_settings")
                }
                startActivity(intent)
                Log.d(TAG, "Redirected to app pen settings")
            }, 100)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to redirect to app pen settings", e)
        }
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) {
            Log.d(TAG, "onKeyEvent: event is null")
            return false
        }

        // 모든 키 이벤트 로그 (펜 버튼 디버깅용)
        val action = if (event.action == KeyEvent.ACTION_DOWN) "DOWN" else "UP"
        val deviceName = event.device?.name ?: "unknown"
        Log.d(TAG, "onKeyEvent: keyCode=${event.keyCode}, action=$action, device=$deviceName, source=${event.source}")

        // 펜 버튼 이벤트 처리 (최우선)
        if (com.minsoo.ultranavbar.util.PenButtonHandler.isPenButtonEvent(event)) {
            Log.d(TAG, "onKeyEvent: Detected pen button event, handling...")
            val handled = com.minsoo.ultranavbar.util.PenButtonHandler.handlePenButtonEvent(this, event)
            if (handled) {
                Log.d(TAG, "onKeyEvent: pen button event consumed")
                return true
            }
            Log.d(TAG, "onKeyEvent: pen button event not consumed, passing through to system")
            return false
        }

        // 현재 앱에서 키보드 단축키가 비활성화되어 있으면 이벤트 전파
        if (currentPackage.isNotEmpty() && settings.isShortcutDisabledForApp(currentPackage)) {
            Log.d(TAG, "onKeyEvent: shortcuts disabled for $currentPackage, passing through")
            return false
        }

        val result = keyEventHandler.handleKeyEvent(event)
        Log.d(TAG, "onKeyEvent: result=$result (consumed=$result)")
        return result
    }

    // ===== 화면 방향 고정 기능 =====

    /**
     * 블루투스 장치가 키보드인지 확인
     */
    private fun isBluetoothKeyboard(device: android.bluetooth.BluetoothDevice): Boolean {
        return try {
            val deviceClass = device.bluetoothClass ?: return false
            val majorClass = deviceClass.majorDeviceClass
            majorClass == android.bluetooth.BluetoothClass.Device.Major.PERIPHERAL ||
            majorClass == android.bluetooth.BluetoothClass.Device.Major.COMPUTER
        } catch (e: Exception) {
            Log.e(TAG, "Failed to check if device is keyboard", e)
            false
        }
    }

    /**
     * 화면 방향 고정 적용 (오버레이 윈도우의 screenOrientation 사용)
     * 이 방식은 앱 자체의 orientation 설정도 무시하고 강제로 방향 고정
     */
    private fun applyOrientationLock() {
        val lockMode = settings.keyboardOrientationLock
        if (lockMode == 0) {
            Log.d(TAG, "Orientation lock is disabled in settings")
            return
        }

        // 기존 오버레이 제거
        removeOrientationLockOverlay()

        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager

            // 투명 오버레이 생성
            val view = android.view.View(this).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            }

            // 화면 방향 설정
            val screenOrientation = when (lockMode) {
                1 -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                2 -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else -> return
            }

            val params = android.view.WindowManager.LayoutParams().apply {
                type = android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                format = android.graphics.PixelFormat.TRANSLUCENT
                flags = android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                width = 1  // 최소 크기 (보이지 않음)
                height = 1
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
                x = 0
                y = 0
                this.screenOrientation = screenOrientation
            }

            wm.addView(view, params)
            orientationLockView = view

            Log.d(TAG, "Applied orientation lock overlay: ${if (lockMode == 1) "landscape" else "portrait"}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply orientation lock overlay", e)
        }
    }

    /**
     * 화면 방향 고정 오버레이 제거
     */
    private fun removeOrientationLockOverlay() {
        orientationLockView?.let { view ->
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
                wm.removeView(view)
                Log.d(TAG, "Removed orientation lock overlay")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to remove orientation lock overlay", e)
            }
            orientationLockView = null
        }
    }

    /**
     * 화면 방향 고정 해제
     */
    private fun removeOrientationLock() {
        removeOrientationLockOverlay()
        Log.d(TAG, "Orientation lock removed")
    }

    /**
     * 현재 연결된 물리 키보드 확인 및 방향 고정 적용
     */
    private fun checkAndApplyOrientationLock() {
        val lockMode = settings.keyboardOrientationLock
        if (lockMode == 0) {
            Log.d(TAG, "Orientation lock is disabled")
            return
        }

        // InputDevice API로 실제 연결된 물리 키보드 확인
        // (bondedDevices는 페어링만 된 기기도 포함하므로 부정확)
        if (hasConnectedPhysicalKeyboard()) {
            Log.d(TAG, "Physical keyboard connected on service start, applying orientation lock")
            applyOrientationLock()
        }
    }

    /**
     * 실제 연결된 물리 키보드가 있는지 확인
     * BT API 대신 InputDevice API 사용 (권한 불필요, 실제 연결 상태 반영)
     */
    private fun hasConnectedPhysicalKeyboard(): Boolean {
        val deviceIds = android.view.InputDevice.getDeviceIds()
        for (id in deviceIds) {
            val device = android.view.InputDevice.getDevice(id) ?: continue
            if (device.sources and android.view.InputDevice.SOURCE_KEYBOARD == android.view.InputDevice.SOURCE_KEYBOARD &&
                device.keyboardType == android.view.InputDevice.KEYBOARD_TYPE_ALPHABETIC &&
                !device.isVirtual) {
                Log.d(TAG, "Physical keyboard found: ${device.name}")
                return true
            }
        }
        return false
    }

    // ===== 자동 터치 기능 =====

    /**
     * 지정된 좌표에 터치(탭) 제스처 수행
     *
     * 개선된 제스처 방식:
     * 1. 단일 포인트 Path (Android CTS 권장 방식) — 불필요한 이동 제거
     * 2. 충분한 터치 지속 시간 (50ms) — 너무 짧으면 무시, 너무 길면 long-press
     * 3. startTime 조정 가능 — 펜 버튼 이벤트 완료 후 실행을 위해
     * 4. 화면 경계 클램핑 — 잘못된 좌표로 인한 실패 방지
     *
     * @param x X 좌표
     * @param y Y 좌표
     * @param callback 결과 콜백 (선택)
     * @param startDelay 제스처 시작 전 딜레이 (ms)
     * @return 제스처 디스패치 성공 여부
     */
    fun performTap(
        x: Float,
        y: Float,
        callback: GestureResultCallback? = null,
        startDelay: Long = 0L
    ): Boolean {
        if (x < 0 || y < 0) {
            Log.w(TAG, "performTap: Invalid coordinates ($x, $y)")
            return false
        }

        return try {
            // 화면 경계 내로 좌표 클램핑
            val displayMetrics = resources.displayMetrics
            val maxX = displayMetrics.widthPixels.toFloat() - 1f
            val maxY = displayMetrics.heightPixels.toFloat() - 1f
            val clampedX = x.coerceIn(0f, maxX)
            val clampedY = y.coerceIn(0f, maxY)

            // 탭 제스처: moveTo → lineTo 로 미세 이동 포함
            // 일부 Android 디바이스/앱에서 zero-length path(moveTo만)를 무시하므로
            // 1px 오프셋 이동을 추가하여 유효한 제스처로 인식시킴
            val offsetX = (clampedX + 1f).coerceAtMost(maxX)
            val path = Path().apply {
                moveTo(clampedX, clampedY)
                lineTo(offsetX, clampedY)
            }

            // 터치 지속 시간: 100ms (탭으로 인식되기 충분하며 long-press 미만)
            // 50ms는 일부 앱/기기에서 너무 짧아 무시될 수 있음
            val strokeDescription = GestureDescription.StrokeDescription(
                path,
                startDelay,
                100L
            )

            val gestureBuilder = GestureDescription.Builder()
                .addStroke(strokeDescription)
                .build()

            val result = dispatchGesture(
                gestureBuilder,
                callback ?: object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        Log.d(TAG, "performTap: Gesture completed at ($clampedX, $clampedY)")
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        Log.w(TAG, "performTap: Gesture cancelled at ($clampedX, $clampedY)")
                    }
                },
                handler
            )

            Log.d(TAG, "performTap: dispatchGesture result=$result at ($clampedX, $clampedY)")
            result
        } catch (e: Exception) {
            Log.e(TAG, "performTap: Failed to dispatch gesture", e)
            false
        }
    }

    /**
     * 저장된 노드 정보를 기반으로 UI 요소 클릭
     * 화면 방향에 상관없이 동작
     *
     * @param nodeId 리소스 ID (예: com.example:id/button)
     * @param nodeText 텍스트 내용
     * @param nodeDesc contentDescription
     * @param nodePackage 패키지 이름 (특정 앱에서만 클릭)
     * @return 클릭 성공 여부
     */
    fun performNodeClick(
        nodeId: String?,
        nodeText: String?,
        nodeDesc: String?,
        nodePackage: String?
    ): Boolean {
        // 매 시도마다 새로운 rootInActiveWindow 가져오기
        val rootNode = rootInActiveWindow ?: run {
            Log.w(TAG, "performNodeClick: No active window")
            return false
        }

        var targetRoot: AccessibilityNodeInfo? = null
        try {
            // 패키지 확인 (선택사항) - 패키지 불일치 시에도 노드 찾기 시도
            val currentPackage = rootNode.packageName?.toString()
            val requestedPackage = nodePackage?.takeIf { it.isNotBlank() }
            targetRoot = if (!requestedPackage.isNullOrEmpty() && currentPackage != requestedPackage) {
                var altRoot: AccessibilityNodeInfo? = null
                val windowList = windows.toList()
                for (window in windowList) {
                    if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                    val root = try { window.root } catch (e: Exception) { null } ?: continue
                    val pkg = root.packageName?.toString()
                    if (pkg == requestedPackage) {
                        altRoot = root
                        break
                    }
                    root.recycle()
                }
                if (altRoot == null) {
                    Log.d(TAG, "performNodeClick: Package mismatch ($currentPackage vs $requestedPackage), aborting")
                    rootNode.recycle()
                    return false
                }
                Log.d(TAG, "performNodeClick: Switching root from $currentPackage to $requestedPackage")
                altRoot
            } else {
                rootNode
            }

            val activeRoot = targetRoot ?: rootNode

            // 노드 찾기 (여러 방법 시도)
            var targetNode: AccessibilityNodeInfo? = null

            // 1. Resource ID
            if (!nodeId.isNullOrEmpty()) {
                val nodes = activeRoot.findAccessibilityNodeInfosByViewId(nodeId)
                if (nodes.isNotEmpty()) {
                    for (node in nodes) {
                        if (node.isClickable || node.isCheckable) {
                            targetNode = node
                            break
                        }
                    }
                    if (targetNode == null) {
                        targetNode = nodes[0]
                    }
                    for (node in nodes) {
                        if (node != targetNode) {
                            node.recycle()
                        }
                    }
                    Log.d(TAG, "performNodeClick: Found node by ID: $nodeId")
                }
            }

            // 2. Find by text (partial match)
            if (!nodeText.isNullOrEmpty() && targetNode == null) {
                val nodes = activeRoot.findAccessibilityNodeInfosByText(nodeText)
                // Exact match first
                for (node in nodes) {
                    val text = node.text?.toString()
                    if (text == nodeText) {
                        targetNode = node
                        Log.d(TAG, "performNodeClick: Found node by exact text: $nodeText")
                        break
                    }
                }
                // Fallback to clickable partial match
                if (targetNode == null) {
                    for (node in nodes) {
                        if (node.isClickable || node.isCheckable) {
                            targetNode = node
                            Log.d(TAG, "performNodeClick: Found clickable node containing text: $nodeText")
                            break
                        }
                    }
                }
                // Recycle unused nodes
                for (node in nodes) {
                    if (node != targetNode) {
                        node.recycle()
                    }
                }
            }

            // 3. Find by contentDescription
            if (!nodeDesc.isNullOrEmpty() && targetNode == null) {
                targetNode = findNodeByContentDescription(activeRoot, nodeDesc)
                if (targetNode != null) {
                    Log.d(TAG, "performNodeClick: Found node by description: $nodeDesc")
                }
            }

            if (targetNode == null) {
                Log.w(TAG, "performNodeClick: Node not found (id=$nodeId, text=$nodeText, desc=$nodeDesc)")
                activeRoot.recycle()
                if (activeRoot != rootNode) {
                    rootNode.recycle()
                }
                return false
            }

            // 클릭 수행 - 노드가 클릭 불가능하면 클릭 가능한 부모 찾기
            val displayMetrics = resources.displayMetrics
            val screenBounds = android.graphics.Rect(
                0,
                0,
                displayMetrics.widthPixels,
                displayMetrics.heightPixels
            )
            val minSizePx = (displayMetrics.density * 24f).toInt()
            val isLauncherContext = !nodePackage.isNullOrEmpty() && windowAnalyzer.isLauncherPackage(nodePackage)
            fun isEditableLike(node: AccessibilityNodeInfo): Boolean {
                if (node.isEditable) return true
                val className = node.className?.toString() ?: ""
                if (className.contains("EditText", ignoreCase = true) ||
                    className.contains("Search", ignoreCase = true)
                ) return true
                val viewId = try { node.viewIdResourceName } catch (_: Exception) { null }
                if (!viewId.isNullOrEmpty()) {
                    val lower = viewId.lowercase()
                    if (lower.contains("search") || lower.contains("edit")) return true
                }
                return false
            }
            fun computeTapBounds(node: AccessibilityNodeInfo): android.graphics.Rect? {
                val screenWidth = screenBounds.width()
                val screenHeight = screenBounds.height()
                if (screenWidth <= 0 || screenHeight <= 0) return null

                var best: android.graphics.Rect? = null
                var bestScore = Float.MAX_VALUE
                val parentsToRecycle = ArrayList<AccessibilityNodeInfo>(8)
                var current: AccessibilityNodeInfo? = node
                var depth = 0
                while (current != null && depth < 10) {
                    val bounds = android.graphics.Rect()
                    try {
                        current.getBoundsInScreen(bounds)
                    } catch (_: Exception) {
                        // ignore
                    }
                    if (bounds.width() > 0 && bounds.height() > 0) {
                        val widthRatio = bounds.width().toFloat() / screenWidth
                        val heightRatio = bounds.height().toFloat() / screenHeight
                        val areaRatio = widthRatio * heightRatio
                        val centerYRatio = bounds.exactCenterY() / screenHeight
                        val tooSmall = bounds.width() < minSizePx || bounds.height() < minSizePx
                        val tooLarge = widthRatio > 0.98f || heightRatio > 0.98f
                        val topBar = isLauncherContext && centerYRatio < 0.18f && heightRatio < 0.25f
                        val editableLike = isLauncherContext && isEditableLike(current)
                        if (!tooSmall && !tooLarge && !topBar && !editableLike) {
                            if (areaRatio < bestScore) {
                                bestScore = areaRatio
                                best = android.graphics.Rect(bounds)
                            }
                        }
                    }
                    val parent = current.parent
                    if (parent != null) {
                        parentsToRecycle.add(parent)
                    }
                    current = parent
                    depth++
                }
                for (parent in parentsToRecycle) {
                    try {
                        parent.recycle()
                    } catch (_: Exception) {}
                }
                return if (bestScore != Float.MAX_VALUE) best else null
            }
            val tapBounds = computeTapBounds(targetNode)

            fun canPerformClick(node: AccessibilityNodeInfo): Boolean {
                if (node.isClickable || node.isCheckable) return true
                return try {
                    node.actionList?.any { it.id == AccessibilityNodeInfo.ACTION_CLICK } == true ||
                        (node.actions and AccessibilityNodeInfo.ACTION_CLICK) != 0
                } catch (_: Exception) {
                    false
                }
            }

            var result = false
            val directClickable = canPerformClick(targetNode)
            result = try {
                targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } catch (_: Exception) {
                false
            }
            Log.d(TAG, "performNodeClick: Direct click result=$result (clickable=$directClickable)")

            if (!result) {
                val focused = try {
                    targetNode.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS) ||
                        targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                } catch (_: Exception) {
                    false
                }
                if (focused) {
                    val focusedResult = try {
                        targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    } catch (_: Exception) {
                        false
                    }
                    Log.d(TAG, "performNodeClick: Focused click result=$focusedResult")
                    result = focusedResult
                }
            }

            if (!result) {
                var parent = targetNode.parent
                var depth = 0
                while (parent != null && depth < 10 && !result) {
                    val parentClickable = canPerformClick(parent)
                    val parentResult = try {
                        parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    } catch (_: Exception) {
                        false
                    }
                    Log.d(
                        TAG,
                        "performNodeClick: Parent click result=$parentResult (depth=$depth, clickable=$parentClickable)"
                    )
                    result = parentResult
                    val grandParent = parent.parent
                    parent.recycle()
                    parent = grandParent
                    depth++
                }
                parent?.recycle()
            }

            if (!result) {
                val bounds = tapBounds ?: android.graphics.Rect().also {
                    try {
                        targetNode.getBoundsInScreen(it)
                    } catch (_: Exception) {
                        // ignore
                    }
                }
                if (bounds.width() > 0 && bounds.height() > 0) {
                    val screenHeight = screenBounds.height().toFloat()
                    val centerYRatio = if (screenHeight > 0f) bounds.exactCenterY() / screenHeight else 0f
                    val heightRatio = if (screenHeight > 0f) bounds.height().toFloat() / screenHeight else 0f
                    val topBar = isLauncherContext && centerYRatio < 0.18f && heightRatio < 0.25f
                    val editableLike = isLauncherContext && isEditableLike(targetNode)
                    if (topBar || editableLike) {
                        Log.d(
                            TAG,
                            "performNodeClick: Skipping fallback tap (topBar=$topBar, editable=$editableLike, centerYRatio=$centerYRatio, heightRatio=$heightRatio)"
                        )
                    } else {
                        val x = bounds.exactCenterX()
                        val y = bounds.exactCenterY()
                        result = performTap(x, y)
                        Log.d(TAG, "performNodeClick: Fallback tap result=$result at ($x, $y)")
                    }
                }
            }
            targetNode.recycle()
            activeRoot.recycle()
            if (activeRoot != rootNode) {
                rootNode.recycle()
            }
            return result
        } catch (e: Exception) {
            Log.e(TAG, "performNodeClick: Failed", e)
            try {
                if (targetRoot != null) {
                    targetRoot?.recycle()
                    if (targetRoot != rootNode) {
                        rootNode.recycle()
                    }
                } else {
                    rootNode.recycle()
                }
            } catch (_: Exception) {}
            return false
        }
    }

    /**
     * contentDescription으로 노드 찾기 (재귀)
     * 클릭 가능 여부와 관계없이 찾음 (나중에 부모에서 클릭 시도)
     */
    private fun findNodeByContentDescription(node: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        return findNodeByContentDescriptionExact(node, desc)
            ?: findNodeByContentDescriptionContains(node, desc)
    }

    private fun findNodeByContentDescriptionExact(node: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        val nodeDesc = node.contentDescription?.toString()
        if (!nodeDesc.isNullOrEmpty()) {
            if (nodeDesc.equals(desc, ignoreCase = true)) {
                return AccessibilityNodeInfo.obtain(node)
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByContentDescriptionExact(child, desc)
            child.recycle()
            if (result != null) {
                return result
            }
        }

        return null
    }

    private fun findNodeByContentDescriptionContains(node: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        val nodeDesc = node.contentDescription?.toString()
        if (!nodeDesc.isNullOrEmpty()) {
            if (nodeDesc.contains(desc, ignoreCase = true)) {
                return AccessibilityNodeInfo.obtain(node)
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByContentDescriptionContains(child, desc)
            child.recycle()
            if (result != null) {
                return result
            }
        }

        return null
    }
}
