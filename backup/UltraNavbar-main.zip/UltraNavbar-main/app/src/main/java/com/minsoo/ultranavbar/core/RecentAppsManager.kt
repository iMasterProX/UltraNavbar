package com.minsoo.ultranavbar.core

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Process
import android.util.Log
import com.minsoo.ultranavbar.settings.SettingsManager
import com.minsoo.ultranavbar.util.CustomAppIconStore
import com.minsoo.ultranavbar.util.IconPackManager

/**
 * 최근 앱 목록 관리
 *
 * 접근성 이벤트(TYPE_WINDOW_STATE_CHANGED)를 통한 실시간 추적을 primary로,
 * UsageStatsManager를 통한 초기 로드를 secondary로 사용
 */
class RecentAppsManager(
    private val context: Context,
    private val listener: RecentAppsChangeListener
) {
    companion object {
        private const val TAG = "RecentAppsManager"
        const val MAX_RECENT_APPS = 7
        private const val PREFS_NAME = "recent_apps_prefs"
        private const val KEY_RECENT_APPS = "recent_apps_list"
        private const val GOOGLE_QUICKSEARCHBOX_PACKAGE = "com.google.android.googlequicksearchbox"
    }

    /**
     * 최근 앱 변경 리스너
     */
    interface RecentAppsChangeListener {
        fun onRecentAppsChanged(apps: List<RecentAppInfo>)
    }

    /**
     * 최근 앱 정보
     */
    data class RecentAppInfo(
        val packageName: String,
        val icon: Drawable,
        val label: CharSequence,
        val isResizeable: Boolean = true
    )

    // 최근 앱 목록 (index 0 = 가장 최근)
    private val recentApps = mutableListOf<RecentAppInfo>()

    private val settings: SettingsManager = SettingsManager.getInstance(context)
    private val packageManager: PackageManager = context.packageManager
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // 제외할 패키지 목록
    private val excludedPackages: MutableSet<String> = mutableSetOf()

    // 런처 패키지 목록
    private var launcherPackages: Set<String> = emptySet()

    /**
     * 런처 패키지 설정
     */
    fun setLauncherPackages(packages: Set<String>) {
        launcherPackages = packages
        buildExcludedPackages()
    }

    /**
     * 초기 최근 앱 로드 (저장된 목록 우선, 없으면 UsageStatsManager 사용)
     */
    fun loadInitialRecentApps() {
        Log.d(TAG, "Loading initial recent apps")
        val maxCount = maxRecentAppsCount()
        recentApps.clear()

        // 먼저 저장된 목록 로드 시도
        val savedPackages = loadSavedRecentApps()
        if (savedPackages.isNotEmpty()) {
            Log.d(TAG, "Loading from saved list: ${savedPackages.size} apps")
            for (packageName in savedPackages) {
                if (recentApps.size >= maxCount) break

                val icon = loadAppIcon(packageName) ?: continue
                val label = loadAppLabel(packageName) ?: packageName

                recentApps.add(RecentAppInfo(packageName, icon, label, true))
            }
        } else {
            // 저장된 목록이 없으면 UsageStats에서 로드
            Log.d(TAG, "No saved list, loading from UsageStats")
            val recentPackages = queryUsageStats()

            for (packageName in recentPackages) {
                if (recentApps.size >= maxCount) break

                val icon = loadAppIcon(packageName) ?: continue
                val label = loadAppLabel(packageName) ?: packageName

                recentApps.add(RecentAppInfo(packageName, icon, label, true))
            }
        }

        Log.d(TAG, "Loaded ${recentApps.size} initial apps")
        if (recentApps.isNotEmpty()) {
            listener.onRecentAppsChanged(recentApps.toList())
            saveRecentApps() // 로드 후 저장하여 동기화
        }
    }

    /**
     * 포그라운드 앱 변경 시 호출
     */
    fun onForegroundAppChanged(
        packageName: String,
        className: String? = null,
        isOnHomeScreen: Boolean = false,
        isRecentsVisible: Boolean = false
    ) {
        if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE) {
            val isMainSurface = isGoogleMainAppSurface(className)

            if (!isMainSurface) {
                if (
                    isOnHomeScreen &&
                    !isRecentsVisible &&
                    isGoogleLauncherCompanionSurface(className)
                ) {
                    Log.d(TAG, "Excluded Google launcher companion on home: class=${className ?: ""}")
                    removePackage(packageName)
                    return
                }

                Log.d(TAG, "Ignored ambiguous Google surface outside home: class=${className ?: ""}")
                return
            }
        }

        if (isExcluded(packageName)) {
            Log.d(TAG, "Excluded package: $packageName")
            removePackage(packageName)
            return
        }

        // 이미 목록에 있으면 제거 (맨 앞으로 이동하기 위해)
        val existingIndex = recentApps.indexOfFirst { it.packageName == packageName }
        if (existingIndex >= 0) {
            val existing = recentApps.removeAt(existingIndex)
            recentApps.add(0, existing)
            Log.d(TAG, "Moved to front: $packageName")
        } else {
            // 새 앱 추가
            val icon = loadAppIcon(packageName)
            if (icon != null) {
                val label = loadAppLabel(packageName) ?: packageName
                recentApps.add(0, RecentAppInfo(packageName, icon, label, true))
                Log.d(TAG, "Added new app: $packageName")
            }
        }

        // 최대 개수 초과 시 마지막 항목 제거
        val maxCount = maxRecentAppsCount()
        while (recentApps.size > maxCount) {
            recentApps.removeAt(recentApps.size - 1)
        }

        listener.onRecentAppsChanged(recentApps.toList())
        saveRecentApps() // 변경사항 저장
    }

    /**
     * 현재 최근 앱 목록 반환
     */
    fun getRecentApps(): List<RecentAppInfo> = recentApps.toList()

    /**
     * 목록 초기화
     */
    fun clear() {
        recentApps.clear()
        Log.d(TAG, "Cleared recent apps")
    }

    fun refreshIcons() {
        if (recentApps.isEmpty()) return

        for (index in recentApps.indices) {
            val existing = recentApps[index]
            val refreshedIcon = loadAppIcon(existing.packageName) ?: continue
            recentApps[index] = existing.copy(icon = refreshedIcon)
        }

        listener.onRecentAppsChanged(recentApps.toList())
    }

    private fun isGoogleMainAppSurface(className: String?): Boolean {
        val cls = className?.trim().orEmpty()
        if (cls.isBlank()) return false

        if (cls.equals("com.google.android.apps.search.googleapp.activity.GoogleAppActivity", ignoreCase = true)) {
            return true
        }

        val simpleName = cls.substringAfterLast('.')
        if (simpleName.equals("GoogleAppActivity", ignoreCase = true)) return true

        return cls.contains("googleapp.activity", ignoreCase = true) &&
            !simpleName.contains("SearchLauncher", ignoreCase = true) &&
            !simpleName.contains("LauncherClient", ignoreCase = true) &&
            !simpleName.contains("Discover", ignoreCase = true)
    }

    private fun isGoogleLauncherCompanionSurface(className: String?): Boolean {
        val cls = className?.trim().orEmpty()
        if (cls.isBlank()) return false

        val simpleName = cls.substringAfterLast('.')
        return simpleName.contains("SearchLauncher", ignoreCase = true) ||
            simpleName.contains("LauncherClient", ignoreCase = true) ||
            simpleName.contains("Discover", ignoreCase = true)
    }

    /**
     * 특정 패키지를 최근 앱 목록에서 제거
     */
    fun removePackage(packageName: String) {
        if (packageName.isBlank()) return
        val removed = recentApps.removeAll { it.packageName == packageName }
        if (!removed) return

        Log.d(TAG, "Removed app from recent list: $packageName")
        listener.onRecentAppsChanged(recentApps.toList())
        saveRecentApps()
    }

    /**
     * 제외 패키지 목록 구성
     */
    private fun buildExcludedPackages() {
        excludedPackages.clear()
        excludedPackages.add("com.android.systemui")
        excludedPackages.add(context.packageName) // 자기 자신
        excludedPackages.addAll(launcherPackages)
        excludedPackages.addAll(settings.disabledApps)

        val removedExcluded = recentApps.removeAll { app -> isExcluded(app.packageName) }
        if (removedExcluded) {
            listener.onRecentAppsChanged(recentApps.toList())
            saveRecentApps()
        }

        Log.d(TAG, "Excluded packages: $excludedPackages")
    }

    /**
     * 패키지가 제외 대상인지 확인
     */
    private fun isExcluded(packageName: String): Boolean {
        if (packageName.isEmpty()) return true
        if (excludedPackages.contains(packageName)) return true

        // 런처블 activity가 없는 시스템 전용 패키지 제외
        return packageManager.getLaunchIntentForPackage(packageName) == null
    }

    private fun isExcludedFromInitialLoad(packageName: String): Boolean {
        if (packageName == GOOGLE_QUICKSEARCHBOX_PACKAGE) return true
        return isExcluded(packageName)
    }

    /**
     * 앱 아이콘 로드
     */
    private fun loadAppIcon(packageName: String): Drawable? {
        CustomAppIconStore.loadDrawable(context, packageName)?.let { return it }
        settings.iconPackPackage?.let { iconPackPackage ->
            IconPackManager.loadDrawableForPackage(context, iconPackPackage, packageName)?.let { return it }
        }
        return try {
            packageManager.getApplicationIcon(packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            Log.w(TAG, "Icon not found for: $packageName")
            null
        }
    }

    /**
     * 앱 레이블 로드
     */
    private fun loadAppLabel(packageName: String): CharSequence? {
        return try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo)
        } catch (e: PackageManager.NameNotFoundException) {
            Log.w(TAG, "Label not found for: $packageName")
            null
        }
    }

    /**
     * UsageStatsManager를 통한 최근 앱 조회
     */
    private fun queryUsageStats(): List<String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            return emptyList()
        }

        // 권한 확인
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
        if (appOps == null) {
            Log.w(TAG, "AppOpsManager not available")
            return emptyList()
        }

        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )

        if (mode != AppOpsManager.MODE_ALLOWED) {
            Log.d(TAG, "PACKAGE_USAGE_STATS not granted, skipping initial load")
            return emptyList()
        }

        // UsageStatsManager 사용
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        if (usageStatsManager == null) {
            Log.w(TAG, "UsageStatsManager not available")
            return emptyList()
        }

        val endTime = System.currentTimeMillis()
        val startTime = endTime - 24 * 60 * 60 * 1000 // 24시간 전

        return try {
            val usageStats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                startTime,
                endTime
            )

            usageStats
                .asSequence()
                .sortedByDescending { it.lastTimeUsed }
                .map { it.packageName }
                .distinct()
                .filter { !isExcludedFromInitialLoad(it) }
                .take(maxRecentAppsCount())
                .toList()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to query usage stats", e)
            emptyList()
        }
    }

    /**
     * 최근 앱 목록을 SharedPreferences에 저장
     */
    private fun saveRecentApps() {
        val packageNames = recentApps.map { it.packageName }
        val joinedString = packageNames.joinToString(",")
        prefs.edit().putString(KEY_RECENT_APPS, joinedString).apply()
        Log.d(TAG, "Saved ${packageNames.size} recent apps")
    }

    /**
     * SharedPreferences에서 저장된 최근 앱 목록 로드
     */
    private fun loadSavedRecentApps(): List<String> {
        val joinedString = prefs.getString(KEY_RECENT_APPS, null) ?: return emptyList()
        if (joinedString.isEmpty()) return emptyList()

        return joinedString.split(",")
            .filter { it.isNotEmpty() && !isExcludedFromInitialLoad(it) }
            .take(maxRecentAppsCount())
    }

    private fun maxRecentAppsCount(): Int {
        return MAX_RECENT_APPS
    }
}
